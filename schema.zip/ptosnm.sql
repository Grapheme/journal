-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Сен 06 2013 г., 14:07
-- Версия сервера: 5.1.40-community
-- Версия PHP: 5.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `ptosnm`
--
CREATE DATABASE IF NOT EXISTS `ptosnm` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `ptosnm`;

-- --------------------------------------------------------

--
-- Структура таблицы `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `signdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `email` (`login`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Очистить таблицу перед добавлением данных `accounts`
--

TRUNCATE TABLE `accounts`;
--
-- Дамп данных таблицы `accounts`
--

INSERT INTO `accounts` (`id`, `login`, `password`, `signdate`, `active`) VALUES
(2, 'admin', 'e10adc3949ba59abbe56e057f20f883e', '2013-09-03 08:28:59', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE IF NOT EXISTS `authors` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` varchar(100) NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(100) NOT NULL,
  `ru_name` varchar(100) NOT NULL,
  `en_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ru_position` varchar(255) NOT NULL,
  `en_position` varchar(255) NOT NULL,
  `ru_abbreviation_institution` varchar(100) NOT NULL,
  `ru_decipher_institution` text NOT NULL,
  `ru_address` text NOT NULL,
  `en_abbreviation_institution` varchar(100) NOT NULL,
  `en_decipher_institution` text NOT NULL,
  `en_address` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Очистить таблицу перед добавлением данных `authors`
--

TRUNCATE TABLE `authors`;
--
-- Дамп данных таблицы `authors`
--

INSERT INTO `authors` (`id`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`, `page_url`, `ru_name`, `en_name`, `email`, `ru_position`, `en_position`, `ru_abbreviation_institution`, `ru_decipher_institution`, `ru_address`, `en_abbreviation_institution`, `en_decipher_institution`, `en_address`) VALUES
(1, 'Харсеев В.А.', 'Харсеев В.А.', '', 'Kharseev V.', 'Kharseev V.', '', '', 'Харсеев В.А.', 'Kharseev V.', 'vkharseev@gmail.com', 'Доктор физико-математических наук', 'Doctor of Physical and Mathematical Sciences', 'ВКГТУ', 'Восточно-Казанский технический Университет им Д.Серикбаева', '', 'EKSTU', 'East Kazan Technical University D.SERIKBAEV', ''),
(2, 'Самойлов А.Г.', 'Самойлов А.Г.', '', 'Samoilov A.', 'Samoilov A.', '', '', 'Самойлов А.Г.', 'Samoilov A.', 'andrew.samoilov@gmail.com', 'Начальство', 'Director', 'Графема', 'Графема', 'Ростов-на-Дону, ул.Суворова, 52а', 'Grapheme', 'Grapheme', 'Rostov-on-Don, Suvorova 52a');

-- --------------------------------------------------------

--
-- Структура таблицы `issues`
--

DROP TABLE IF EXISTS `issues`;
CREATE TABLE IF NOT EXISTS `issues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` varchar(100) NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(255) NOT NULL,
  `ru_title` varchar(100) NOT NULL,
  `en_title` varchar(100) NOT NULL,
  `number` int(10) unsigned NOT NULL,
  `month` tinyint(2) unsigned NOT NULL,
  `year` int(10) unsigned NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Очистить таблицу перед добавлением данных `issues`
--

TRUNCATE TABLE `issues`;
--
-- Дамп данных таблицы `issues`
--

INSERT INTO `issues` (`id`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`, `page_url`, `ru_title`, `en_title`, `number`, `month`, `year`, `date`) VALUES
(1, 'Выпуск №1 Январь 2013', 'Выпуск №1 Январь 2013', '', 'Issue #1 January 2013', 'Issue #1 January 2013', '', '', 'Выпуск №1 Январь 2013', 'Issue #1 January 2013', 1, 1, 2013, '2013-09-05 15:26:22'),
(2, 'Выпуск №2 Февраль 2013', 'Выпуск №2 Февраль 2013', '', 'Issue #1 Fabruary 2013', 'Issue #1 Fabruary 2013', '', '', 'Выпуск №2 Февраль 2013', 'Issue #1 Fabruary 2013', 2, 2, 2013, '2013-09-05 15:34:16');

-- --------------------------------------------------------

--
-- Структура таблицы `keywords`
--

DROP TABLE IF EXISTS `keywords`;
CREATE TABLE IF NOT EXISTS `keywords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `word_hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Очистить таблицу перед добавлением данных `keywords`
--

TRUNCATE TABLE `keywords`;
-- --------------------------------------------------------

--
-- Структура таблицы `matching`
--

DROP TABLE IF EXISTS `matching`;
CREATE TABLE IF NOT EXISTS `matching` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `word` int(10) unsigned NOT NULL,
  `publication` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Очистить таблицу перед добавлением данных `matching`
--

TRUNCATE TABLE `matching`;
-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` text NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `ru_content` text NOT NULL,
  `en_content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Очистить таблицу перед добавлением данных `pages`
--

TRUNCATE TABLE `pages`;
--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`, `page_url`, `title`, `ru_content`, `en_content`) VALUES
(1, 'Фазовые переходы, упорядоченные состояния и новые материалы', 'Фазовые переходы, упорядоченные состояния и новые материалы', '', 'Phase transitions, ordered states and new materials', 'Phase transitions, ordered states and new materials', '', 'home', 'Главная страница', '<header>\n<h1 class="article-h1">Фазовые переходы, упорядоченные состояния и новые материалы</h1>\n<p class="desc">\n	        Журнал «Фазовые переходы, упорядоченные состояния и новые материалы» - первый в России электронный журнал,  посвященный широкому кругу вопросов из области физики конденсированных сред.  В нем публикуются результаты оригинальных исследований и обзоры, посвященные актуальным прикладным и  фундаментальным вопросам по темам:\n</p>\n</header>\n<p class="themes">\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки</li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики</li>\n	<li class="themes-item">Сверхпроводимость</li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур</li>\n	<li class="themes-item">Теория фазовых диаграмм</li>\n	<li class="themes-item">Свойства металлов и сплавов</li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации</li>\n	<li class="themes-item">Напряженные состояния и пластичность</li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности</li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности</li>\n	<li class="themes-item">Полимеры, жидкие кристаллы</li>\n	<li class="themes-item">Электронные свойства твердых тел</li>\n	<li class="themes-item">Атомные кластеры, фуллерены</li>\n</ul>\n<p class="freq-div">\n</p>\n<p>\n	        Периодичность журнала в свет - ежемесячно. Учредителем является Институт физики Южного федерального университета.\n</p>', '<header>\n<h1 class="article-h1">Phase transitions, ordered states and new materials</h1>\n<p class="desc">\n	          Журнал «Фазовые переходы, упорядоченные состояния и новые материалы» - первый в России электронный журнал,  посвященный широкому кругу вопросов из области физики конденсированных сред.  В нем публикуются результаты оригинальных исследований и обзоры, посвященные актуальным прикладным и  фундаментальным вопросам по темам:\n</p>\n</header>\n<p class="themes">\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки</li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики</li>\n	<li class="themes-item">Сверхпроводимость</li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур</li>\n	<li class="themes-item">Теория фазовых диаграмм</li>\n	<li class="themes-item">Свойства металлов и сплавов</li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации</li>\n	<li class="themes-item">Напряженные состояния и пластичность</li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности</li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности</li>\n	<li class="themes-item">Полимеры, жидкие кристаллы</li>\n	<li class="themes-item">Электронные свойства твердых тел</li>\n	<li class="themes-item">Атомные кластеры, фуллерены</li>\n</ul>\n<p class="freq-div">\n</p>\n<p>\n	          Периодичность журнала в свет - ежемесячно. Учредителем является Институт физики Южного федерального университета.\n</p>'),
(2, 'Выпуски', 'Выпуски', '', '', '', '', 'issues', 'Выпуски', '<header>\n<h1 class="article-h1">Выпуски</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>', '<header>\n<h1 class="article-h1">Issues</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>'),
(3, 'Информация для авторов', 'Информация для авторов', '', '', '', '', 'for-authors', 'Информация для авторов', '<header>\n<h1 class="article-h1">Информация для авторов</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section>\n<p class="themes">\n</p>\n<p class="theme-header">\n	 В нашем журнале публикуются оригинальные работы и обзоры по широкому спектру вопросов физики твердого тела. Основные рубрики:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки         </li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики         </li>\n	<li class="themes-item">Сверхпроводимость         </li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур         </li>\n	<li class="themes-item">Теория фазовых диаграмм         </li>\n	<li class="themes-item">Свойства металлов и сплавов         </li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации         </li>\n	<li class="themes-item">Напряженные состояния и пластичность         </li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности         </li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности         </li>\n	<li class="themes-item">Полимеры, жидкие кристаллы         </li>\n	<li class="themes-item">Электронные свойства твердых тел         </li>\n	<li class="themes-item">Атомные кластеры, фуллерены         </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	 Каждая статья должна сопровождаться следующей информацией:\n</p>\n<ol class="ord-list">\n	<li class="ord-item">         название статьи на русском и английском языках         </li>\n	<li class="ord-item">         информация о каждом из соавторов (см. ниже)         </li>\n	<li class="ord-item">         краткая аннотация на русском и английском языках         </li>\n	<li class="ord-item">         название рубрики журнала, к которой следует отнести статью          </li>\n	<li class="ord-item">         список ключевых слов на русском и английском языках (см. ниже).         </li>\n</ol>\n</section><section>\n<p class="theme-header">\n	 Информация об авторе или соавторах статьи должна быть подана в следующем виде:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">если в нашем журнале уже были опубликованы статьи с участием данного автора, достаточно указать это и предоставить фамилию, имя и отчество автора          </li>\n	<li class="themes-item">если автор публикуется у нас впервые, следует указать:\n	<ol class="ord-list">\n		<li class="ord-item">         фамилию, имя, отчество на русском языке, а также фамилию и имя на английском языке (для иностранных авторов – только на английском)         </li>\n		<li class="ord-item">         название учреждения, в котором работает автор, на русском и английском языках, а также ссылку на сайт учреждения (если он есть)         </li>\n		<li class="ord-item">         электронный адрес (если он есть) и информацию о том, согласен ли автор, чтобы этот электронный адрес был опубликован на его страничке нашего сайта         </li>\n	</ol>\n	</li>\n</ul>\n</section><section class="notes">\n<p class="theme-header">\n	 Замечания:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Словосочетание "ключевые слова" следует понимать традиционным для научных журналов способом. Так, "теория симметрии" или "рентгеноструктурный анализ" могут быть выбраны в качестве ключевых слов, несмотря на то, что с точки зрения филологии словами они не являются. При выборе самих ключевых слов для пометки статьи также следует руководствоваться традициями журналов по физике твердого тела. Кроме того, следует учитывать, что в электронном формате журнала ключевые слова служат для быстрого поиска статей по схожей тематике – таким образом, имеет определенный смысл в качестве ключевых слов выбирать то, что уже служит в таком качестве в тех статьях нашего журнала, которые, как Вам кажется, близки по тематике к Вашей статье.          </li>\n	<li class="themes-item">Электронный журнал “Фазовые переходы, упорядоченные состояния и новые материалы” индексируется в нескольких библиографических базах (база данных ФГУП НТЦ Информрегистр, электронная научная библиотека eLIBRARY.ru). Считаем нужным предупредить о том, что некоторые из этих баз не обладают технической возможностью хранить тексты формул в их естественном виде. Например, в случае, если в названии или аннотации статьи, опубликованной в нашем или любом другом журнале, встретится формула “PbFexNb1-xO3”, в базе Информрегистра она, по независящим от нас причинам, будет выглядеть как “PbFexNb1-xO3”.                 </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	 К оформлению текстов статей предъявляются следующие требования:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">редакция принимает только статьи, представленные в электронном виде, в формате doc или tex.          </li>\n	<li class="themes-item">рисунки также следует предоставлять в электронном виде, в любом из распространенных растровых форматов (jpg, gif, pcx, bmp…). Работа по переводу фотографий и снимков других видов в электронный вид, ложится на авторов статьи.          </li>\n	<li class="themes-item">рисунки должны быть выполнены таким образом, чтобы по возможности не нуждаться в последующем редактировании. Все важные детали должны быть изображены так, чтобы быть различимыми при изменении размеров рисунка до ширины в одну стандартную журнальную колонку или до ширины страницы А4. Желательно, чтобы надписи на всех рисунках, относящихся к одной статье, были сделаны в едином стиле.          </li>\n	<li class="themes-item">в случае использования формата doc, желательно, чтобы формулы были набраны в редакторе формул MathType.         </li>\n</ul>\n</section>', '<header>\n<h1 class="article-h1">Information for Authors</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section>\n<p class="themes">\n</p>\n<p class="theme-header">\n	  В нашем журнале публикуются оригинальные работы и обзоры по широкому спектру вопросов физики твердого тела. Основные рубрики:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки         </li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики         </li>\n	<li class="themes-item">Сверхпроводимость         </li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур         </li>\n	<li class="themes-item">Теория фазовых диаграмм         </li>\n	<li class="themes-item">Свойства металлов и сплавов         </li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации         </li>\n	<li class="themes-item">Напряженные состояния и пластичность         </li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности         </li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности         </li>\n	<li class="themes-item">Полимеры, жидкие кристаллы         </li>\n	<li class="themes-item">Электронные свойства твердых тел         </li>\n	<li class="themes-item">Атомные кластеры, фуллерены         </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	  Каждая статья должна сопровождаться следующей информацией:\n</p>\n<ol class="ord-list">\n	<li class="ord-item">         название статьи на русском и английском языках         </li>\n	<li class="ord-item">         информация о каждом из соавторов (см. ниже)         </li>\n	<li class="ord-item">         краткая аннотация на русском и английском языках         </li>\n	<li class="ord-item">         название рубрики журнала, к которой следует отнести статью          </li>\n	<li class="ord-item">         список ключевых слов на русском и английском языках (см. ниже).         </li>\n</ol>\n</section><section>\n<p class="theme-header">\n	  Информация об авторе или соавторах статьи должна быть подана в следующем виде:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">если в нашем журнале уже были опубликованы статьи с участием данного автора, достаточно указать это и предоставить фамилию, имя и отчество автора          </li>\n	<li class="themes-item">если автор публикуется у нас впервые, следует указать:\n	<ol class="ord-list">\n		<li class="ord-item">         фамилию, имя, отчество на русском языке, а также фамилию и имя на английском языке (для иностранных авторов – только на английском)         </li>\n		<li class="ord-item">         название учреждения, в котором работает автор, на русском и английском языках, а также ссылку на сайт учреждения (если он есть)         </li>\n		<li class="ord-item">         электронный адрес (если он есть) и информацию о том, согласен ли автор, чтобы этот электронный адрес был опубликован на его страничке нашего сайта         </li>\n	</ol>\n	</li>\n</ul>\n</section><section class="notes">\n<p class="theme-header">\n	  Замечания:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Словосочетание "ключевые слова" следует понимать традиционным для научных журналов способом. Так, "теория симметрии" или "рентгеноструктурный анализ" могут быть выбраны в качестве ключевых слов, несмотря на то, что с точки зрения филологии словами они не являются. При выборе самих ключевых слов для пометки статьи также следует руководствоваться традициями журналов по физике твердого тела. Кроме того, следует учитывать, что в электронном формате журнала ключевые слова служат для быстрого поиска статей по схожей тематике – таким образом, имеет определенный смысл в качестве ключевых слов выбирать то, что уже служит в таком качестве в тех статьях нашего журнала, которые, как Вам кажется, близки по тематике к Вашей статье.          </li>\n	<li class="themes-item">Электронный журнал “Фазовые переходы, упорядоченные состояния и новые материалы” индексируется в нескольких библиографических базах (база данных ФГУП НТЦ Информрегистр, электронная научная библиотека eLIBRARY.ru). Считаем нужным предупредить о том, что некоторые из этих баз не обладают технической возможностью хранить тексты формул в их естественном виде. Например, в случае, если в названии или аннотации статьи, опубликованной в нашем или любом другом журнале, встретится формула “PbFexNb1-xO3”, в базе Информрегистра она, по независящим от нас причинам, будет выглядеть как “PbFexNb1-xO3”.                 </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	  К оформлению текстов статей предъявляются следующие требования:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">редакция принимает только статьи, представленные в электронном виде, в формате doc или tex.          </li>\n	<li class="themes-item">рисунки также следует предоставлять в электронном виде, в любом из распространенных растровых форматов (jpg, gif, pcx, bmp…). Работа по переводу фотографий и снимков других видов в электронный вид, ложится на авторов статьи.          </li>\n	<li class="themes-item">рисунки должны быть выполнены таким образом, чтобы по возможности не нуждаться в последующем редактировании. Все важные детали должны быть изображены так, чтобы быть различимыми при изменении размеров рисунка до ширины в одну стандартную журнальную колонку или до ширины страницы А4. Желательно, чтобы надписи на всех рисунках, относящихся к одной статье, были сделаны в едином стиле.          </li>\n	<li class="themes-item">в случае использования формата doc, желательно, чтобы формулы были набраны в редакторе формул MathType.         </li>\n</ul>\n</section>'),
(4, 'Редколлегия', 'Редколлегия', '', '', '', '', 'editorial', 'Редколлегия', '<header>\n<h1 class="article-h1">Редколлегия</h1>\n</header><section class="editorial">\n<ul class="ed-position">\n	<li>\n	<p class="position-header">\n		Главный редактор\n	</p>\n	<dl class="name-prof">\n		<dt>Сахненко Владимир Павлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		Заместители главного редактора\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Панченко Евгений Михайлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		Ученый секретарь\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		Члены редакционного совета\n	</p>\n	<dl class="name-prof">\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n</ul>\n</section>', '<header>\n<h1 class="article-h1">Editorial</h1>\n</header><section class="editorial">\n<ul class="ed-position">\n	<li>\n	<p class="position-header">\n		 Главный редактор\n	</p>\n	<dl class="name-prof">\n		<dt>Сахненко Владимир Павлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		 Заместители главного редактора\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Панченко Евгений Михайлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		 Ученый секретарь\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		 Члены редакционного совета\n	</p>\n	<dl class="name-prof">\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n</ul>\n</section>'),
(5, 'Полезные ссылки', 'Полезные ссылки', '', '', '', '', 'usefull-links', 'Полезные ссылки', '<header>\n<h1 class="article-h1">Полезные ссылки</h1>\n</header><section class="useful-links">\n<dl>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n</dl>\n</section>', ''),
(6, 'Поиск', 'Поиск', '', 'Search', 'Search', '', 'search', 'Поиск', '<header>\n<h1 class="article-h1">Поиск</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>', '<header>\n<h1 class="article-h1">Search</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>'),
(7, 'Авторы', 'Авторы', '', '', '', '', 'authors', 'Авторы', '<header>\n				<h1 class="article-h1">Авторы</h1>\n				<div class="delicate-design-stroke"></div>\n			</header>', '<header>\n				<h1 class="article-h1">Authors</h1>\n				<div class="delicate-design-stroke"></div>\n			</header>'),
(8, 'Ключевые слова', 'Ключевые слова', '', '', '', '', 'keywords', 'Ключевые слова', '<header>\n<h1 class="article-h1">Ключевые слова</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>', '<header>\n<h1 class="article-h1">Keywords</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>'),
(9, 'Учреждения', 'Учреждения', '', '', '', '', 'institutions', 'Учреждения', '<header>\n<h1 class="article-h1">Учреждения</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section class="useful-links">\n<ol class="ord-list">\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n</ol>\n</section>', '<header>\n<h1 class="article-h1">Institutions</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section class="useful-links">\n<ol class="ord-list">\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n</ol>\n</section>');

-- --------------------------------------------------------

--
-- Структура таблицы `page_resources`
--

DROP TABLE IF EXISTS `page_resources`;
CREATE TABLE IF NOT EXISTS `page_resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_url` varchar(100) NOT NULL,
  `number` int(10) unsigned NOT NULL,
  `caption` varchar(100) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `thumbnail` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Очистить таблицу перед добавлением данных `page_resources`
--

TRUNCATE TABLE `page_resources`;
-- --------------------------------------------------------

--
-- Структура таблицы `publications`
--

DROP TABLE IF EXISTS `publications`;
CREATE TABLE IF NOT EXISTS `publications` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` varchar(100) NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(255) NOT NULL,
  `ru_title` text NOT NULL,
  `en_title` text NOT NULL,
  `ru_annotation` text NOT NULL,
  `en_annotation` int(11) NOT NULL,
  `ru_content` text NOT NULL,
  `en_content` text NOT NULL,
  `ru_support` text NOT NULL,
  `en_support` text NOT NULL,
  `ru_bibliography` text NOT NULL,
  `en_bibliography` text NOT NULL,
  `ru_document` varchar(150) NOT NULL,
  `en_document` varchar(150) NOT NULL,
  `issue` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Очистить таблицу перед добавлением данных `publications`
--

TRUNCATE TABLE `publications`;
--
-- Дамп данных таблицы `publications`
--

INSERT INTO `publications` (`id`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`, `page_url`, `ru_title`, `en_title`, `ru_annotation`, `en_annotation`, `ru_content`, `en_content`, `ru_support`, `en_support`, `ru_bibliography`, `en_bibliography`, `ru_document`, `en_document`, `issue`) VALUES
(1, 'Кластерообразование в структуре электронно-ионных проводников на основе допированного галлата лантана', 'Кластерообразование в структуре электронно-ионных проводников на основе допированного галлата лантана', '', 'Clustering in the structure of the electron-ion conductors based on doped lanthanum gallate', 'Clustering in the structure of the electron-ion conductors based on doped lanthanum gallate', '', '', 'Кластерообразование в структуре электронно-ионных проводников на основе допированного галлата лантана', 'Clustering in the structure of the electron-ion conductors based on doped lanthanum gallate', '<p>\r\n  Исследованы магнитные свойства и спектры импеданса галлата лантана,  допированного двухвалентными элементами (Ca, Sr, Ba, Mg) и d-элементами с  разными соотношениями переходный металл:          двухвалентный элемент. Показано, что стабилизация структуры  перовскита достигается за счет образования прочных кластеров, включающих  в себя атомы переходного металла, двухвалентного          элемента и вакансии в кислородной подрешетке.  Кластерообразование усиливается с увеличением доли двухвалентного  элемента, при введении магния и при замене стронция на кальций или  барий,          что приводит к уменьшению проводимости за счет блокирования  кислородных вакансий кулоновским полем кластеров.\r\n</p>', 0, '<p>\r\n  Исследованы магнитные свойства и спектры импеданса галлата лантана,  допированного двухвалентными элементами (Ca, Sr, Ba, Mg) и d-элементами с  разными соотношениями переходный металл:          двухвалентный элемент. Показано, что стабилизация структуры  перовскита достигается за счет образования прочных кластеров, включающих  в себя атомы переходного металла, двухвалентного          элемента и вакансии в кислородной подрешетке.  Кластерообразование усиливается с увеличением доли двухвалентного  элемента, при введении магния и при замене стронция на кальций или  барий,          что приводит к уменьшению проводимости за счет блокирования  кислородных вакансий кулоновским полем кластеров.\r\n</p>', '<p>\r\n Clustering in the structure of the electron-ion conductors based on doped lanthanum gallate<br>\r\n The magnetic properties and the impedance spectra lanthanum gallate doped with divalent elements (Ca, Sr, Ba, Mg) and d-elements with different ratios of transition metal to a divalent element. It is shown that the stabilization of the perovskite structure is achieved by forming strong clusters containing a transition metal atoms, a divalent element and vacancies in the oxygen sublattice. Clustering increases with increasing proportion of divalent element, introducing magnesium and strontium replaced by calcium or barium, which leads to decrease in the conductivity due to blocking of oxygen vacancies Coulomb field clusters.\r\n</p>', '<ol class="ord-list">\r\n <li class="ord-item"><span class="gray">РФФИ грант № 08-05_00636</span></li>\r\n <li class="ord-item"><span class="gray">Новосибирский областной фонд поддержки науки и инновационной деятельности грант № 00-00-00000</span></li>\r\n <li class="ord-item"><span class="gray">Фонд имени И.Н.Герасимова грант № 50-04-12345</span></li>\r\n</ol>', '<span class="gray">РФФИ грант № 08-05_00636</span>\r\n<ol class="ord-list">\r\n <li class="ord-item"><span class="gray">Новосибирский областной фонд поддержки науки и инновационной деятельности грант № 00-00-00000</span></li>\r\n <li class="ord-item"><span class="gray">Фонд имени И.Н.Герасимова грант № 50-04-12345</span></li>\r\n</ol>', '<ol class="ord-list">\r\n <li class="ord-item">         Чежина Н. В., Королев Д. А. // ЖОХ. – 2012. – V. 84. – P. 353         </li>\r\n <li class="ord-item">         Келлерман Д. Г., Шалаева Е. В., Гусев А. И. // ФТТ. – 2004. – V. 46. – P. 1633         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2010. – Т. 52. – Вып. 3. – С. 577–584         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2010. – Т. 52. – Вып. 6. – С. 1202–1205          </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2011. – Т. 53. – Вып. 3. – С. 569–572         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2011. – Т. 53. – Вып. 6. – С. 1224–1229         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2012. – Т. 54. – Вып. 2. – С. 378–381         </li>\r\n</ol>', '<ol class="ord-list">\r\n <li class="ord-item">         Чежина Н. В., Королев Д. А. // ЖОХ. – 2012. – V. 84. – P. 353         </li>\r\n <li class="ord-item">         Келлерман Д. Г., Шалаева Е. В., Гусев А. И. // ФТТ. – 2004. – V. 46. – P. 1633         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2010. – Т. 52. – Вып. 3. – С. 577–584         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2010. – Т. 52. – Вып. 6. – С. 1202–1205          </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2011. – Т. 53. – Вып. 3. – С. 569–572         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2011. – Т. 53. – Вып. 6. – С. 1224–1229         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2012. – Т. 54. – Вып. 2. – С. 378–381         </li>\r\n</ol>', '', '', 1),
(2, 'Lorem Ipsum - это текст-"рыба"', 'Lorem Ipsum - это текст-"рыба"', 'Lorem Ipsum - это текст-"рыба"', '', '', '', '', 'Lorem Ipsum - это текст-"рыба"', 'de Finibus Bonorum et Malorum', '<p>\r\n <strong>Lorem Ipsum</strong>- это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n</p>', 0, '<p>\r\n <strong>Lorem Ipsum</strong>- это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n</p>', '<p>\r\n "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."\r\n</p>', '<p>\r\n <strong>Lorem Ipsum</strong>- это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n</p>', '<p>\r\n "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."\r\n</p>', '<p>\r\n <strong>Lorem Ipsum</strong>- это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n</p>', '<p>\r\n "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."\r\n</p>', '', '', 1),
(10, '', '', '', '', '', '', '', 'Документ', 'Document', '', 0, '', '', '', '', '', '', 'download/konferum-kategorii.pdf', '', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `publications_comments`
--

DROP TABLE IF EXISTS `publications_comments`;
CREATE TABLE IF NOT EXISTS `publications_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `publication` int(10) unsigned NOT NULL,
  `issue` int(10) unsigned NOT NULL,
  `account` int(10) unsigned NOT NULL,
  `comment` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Очистить таблицу перед добавлением данных `publications_comments`
--

TRUNCATE TABLE `publications_comments`;
-- --------------------------------------------------------

--
-- Структура таблицы `publications_resources`
--

DROP TABLE IF EXISTS `publications_resources`;
CREATE TABLE IF NOT EXISTS `publications_resources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `publication` int(11) NOT NULL,
  `issue` int(11) NOT NULL,
  `resource` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Очистить таблицу перед добавлением данных `publications_resources`
--

TRUNCATE TABLE `publications_resources`;
-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Очистить таблицу перед добавлением данных `sessions`
--

TRUNCATE TABLE `sessions`;
--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('e1f4c4894584c6c4534ddff3f88c26a2', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; rv:23.0) Gecko/20100101 Firefox/23.0', 1378461977, 'a:4:{s:9:"user_data";s:0:"";s:5:"logon";s:32:"21232f297a57a5a743894a0e4a801fc3";s:7:"account";s:10:"{"id":"2"}";s:7:"profile";s:118:"{"id":"2","login":"admin","password":"e10adc3949ba59abbe56e057f20f883e","signdate":"2013-09-03 12:28:59","active":"1"}";}');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
