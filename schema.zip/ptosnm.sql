-- phpMyAdmin SQL Dump
-- version 3.4.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Сен 18 2013 г., 10:40
-- Версия сервера: 5.1.70
-- Версия PHP: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `ptosnm`
--

-- --------------------------------------------------------

--
-- Структура таблицы `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `vkid` int(11) NOT NULL,
  `vk_access_token` text NOT NULL,
  `facebook_access_token` text NOT NULL,
  `facebookid` bigint(20) NOT NULL,
  `photo` mediumblob NOT NULL,
  `name` varchar(100) NOT NULL,
  `link` varchar(200) NOT NULL,
  `login` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `signdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `email` (`login`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `accounts`
--

INSERT INTO `accounts` (`id`, `group`, `vkid`, `vk_access_token`, `facebook_access_token`, `facebookid`, `photo`, `name`, `link`, `login`, `password`, `signdate`, `active`) VALUES
(1, 0, 0, '', '', 0, '', '', '', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '2013-09-03 08:28:59', 1),
(3, 1, 0, '', 'CAADQjsffLFsBANT4Q5wqqjcjqvZBCtyOkkoY7zC13s2CE9qRiZBFGqtWyomLBk2xYmsXdTZBxRq3DAXisqi2V5nKZCOIF5ZBD09CJZBfeCXIbpG3gjooxLWUGTDLJ8wjtgRhW2HXK1XHl24iWVQsDXUM7kZBjrVrIIBeEhiBf8HH0gKTqZBd3rGy', 100001912017351, 0xffd8ffe000104a46494600010100000100010000fffe003b43524541544f523a2067642d6a7065672076312e3020287573696e6720494a47204a50454720763830292c207175616c697479203d2039300affdb0043000302020302020303030304030304050805050404050a070706080c0a0c0c0b0a0b0b0d0e12100d0e110e0b0b1016101113141515150c0f171816141812141514ffdb00430103040405040509050509140d0b0d1414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414ffc0001108003c003c03012200021101031101ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc4001f0100030101010101010101010000000000000102030405060708090a0bffc400b51100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c03010002110311003f00e9db4786e2e7ca865b887bef29c67f3eb56f56d59f42b00d7db6fad91807b8475530293cbbe4e368ebcf38078359906b425b648d525da3243f9a091cf72ca4feb5f2ff00c7cf8cd3789aedf42d36e8be996cc44922e009e4fc3aa8e71f9fa562df42630723b1f1e7ed290db5d9b7f0d85b88c70f772c3b4376385c8c0e3bfe5581a37ed07ad09d5bcfb7604e58344493f86457cf335d30c7ce573dc53e3bd9838225566fee93c9a870bf53a172ad2c7dada2fc6fd2fc40b1c3a8da2bdc6d0398f6fe5bba7e7debac7f167852e6686d7eca7ed330caec2573dba838af8774cf12dcaaac71dd491851cae7057e95d9f85bc7da869732a4977f69807cdfbe191db8fafbd64fda476d4af671969b1f5fc76ba62c0311bc4081c072483c7739a8058c049da1d973c13839fe55ca7c3ef1fe81afe966d2ee67b4bd087cb904831edd437ea0fd0d7a11b66bc8a1905c2a6100c2caac0fbe768cfe007d2b5854525a1cd38383b33cff00e3ff008b6e7c2ff0bf559a29447733a8b452a4e41738254faeddc6be105bcdf2142085cf5afa8bf6b9d6eeafbc37a5451c7b6de4be62e10eecb04609ce072412718fcebe6ebef096b1a442cf7566f0859046e0e0b2b150d823e8c295ecf53a69c2528de28a052370739e3b13535a5bb4b2aa47b493c6d1c54f65a60ba97cb8f738e33b4727f0af47f877f0ba6d535e8e7bab696d74e8c756cab3b7603fc694aa289d54a83a8ce024d1ae2360b243993f5157b4cd02f6e9b6472b119c08cf3ef5f49cdf0a629a0486d6da24b623f7934ac0b7e03d7dc9af41f00fc15d0f49b78ae1acda47dfbb0c430fc477fa5723c4bb6c772c1a5d4f97dbc3fe23d1e5b6b7837c7ba359471820127047e55f44f80b55d5adbc376e9a93f99719c831c6cc02e0606715b5f187c0f3df789bc2cfa5c3833a3a4bb06005578ce0fe0cd5d6e95acdce8f662d92081406672a17214b31240f619c0fa5141ce7efb383149536a08f17fda134e167e19d26ea521e2b5d66da6978c8c7cc0f3f8d26b7e1cb4d5ac0d8ac09e75cc865794fdf2e13823d80007e156ff6b7f0f5ae81f0e2389eea69aedee63647c6119870463d002793543c0de23b7d5fc2168750754d42240a5d873bb1b41047a8feb5b62e0e16bee74e5951384a1dcf38f879e026b3d7b548eea1216221239403b5f9ce7f957a9eb369756768b2db89171c8308c9fca9b60bb670e06727b77aef34811caa12455653d335e74e4e52d4f529c545591e6b1dcebda725bce97f73144d26d78cc0ae7a6727e62307a7af5af50b5f13dfe99e11fed00af7b2abac61615e599b38c8ec38a4d7f48d3a1b725845083d70315a1f0d92daef53fecf7804b6770be514906413d5783fed01f9537172348ae54c6787757d7af6d24935f48e38b793024b6f824838dcbd72bee3d2bab87c408d1af9f6963732018323c0727f306b7f508ac9eda2892dedd92d9362af96328bc9e3f124d60cf716a8e17fb1da5c01f3c6e501fc370af4a825ecd591f278b9395595cccf8f1f0920f8d3e018d2c2702fec243776a47dd94ed20a37b1cf5ec40af9d340b096cb427b7950c77317c8e8c304329c1c8ec6bec2f0eafd86ea7f24954f3550c79ca90d9cf15e23f16749b6d33c7b75f674d82e544b22f62d923fa7ea6b5cc649a8cfa9b65952cdd3fb8e174dbc01c21aedb42b8caf4ced1c5796db5cbff685da701629cc6b818e303fc6bb6d1e778d700fb5786f5b9ef45d8d4d4f5182ee468a6b8891c7692400af3c1c5747e0d79d6e91cdfc0235daf198ca97620e31c1f5f6ac396cade7406486390edfe3506bbbf83b1c5717d6a924109896ea36f2c200adb79008efd2ae3aa514754e4a14dcdf43b0f167c2ef13e91a69be684c96cc88f2cf67265e31c120f7183d78c75e6b918277923dc24043127e63d39e9c0afae1277d3ee6d6284e229943143d178edffd7cd66dff00c25f08f882e9ef6ef4587ed0e7e7681de10c7a924230049cf271935ed5351778c7a687c3caa393729753ffd9, 'Владимир Харсеев', 'https://www.facebook.com/profile.php?id=100001912017351', '', '', '2013-09-09 14:25:45', 1),
(4, 1, 0, '', 'CAADQjsffLFsBAKNyWeIvExg2CA3UZAKIeqUrE9n8agOZAnlFDDg8wF19UUQZALZBPflWrzSyQWM8MzsVYqMCnKL1YUbxmHXJit1Q6j8cddsVQZBn0iudsZC7STCeJ5oCH4X5bZA6XLpQHJSJDGD4ZC2AktSiBRKdrCJeicBZARJOrVFnsdZBZCr3SmD', 591898451, 0xffd8ffe000104a46494600010100000100010000fffe003b43524541544f523a2067642d6a7065672076312e3020287573696e6720494a47204a50454720763830292c207175616c697479203d2039300affdb0043000302020302020303030304030304050805050404050a070706080c0a0c0c0b0a0b0b0d0e12100d0e110e0b0b1016101113141515150c0f171816141812141514ffdb00430103040405040509050509140d0b0d1414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414ffc0001108003c003c03012200021101031101ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc4001f0100030101010101010101010000000000000102030405060708090a0bffc400b51100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c03010002110311003f00f9fbc7d650f866cee2e6f9dae5938098d819bb0e2bc4545cebfa9ec8e3ccd33708b9e3d857a47c5ab648b4c668d11312a9620609eb5e79e16d624d0f5786f62e5e36cf3dc7715a83dcfa1be0dfec9b73e2e96097c457e34fb0939f2a300cac3f1e95f54693fb187c2fb2b0443a4bde14032f3ccec58f5f5c735c6fc2df8b9e11d3342b2bbd7356b6d3a46456d923f3cd7bcf857e2d785bc57096d1350b7d4822e58c1286e07a8ace4d9bc546c7c47fb487ecdadf0a037897c30197c3af285bab52726d199b0a549e4a1240e79071f879343a0eb73460ec91548cf320fe86bec3f8ebfb44f827c6fe19f11f826da0b9b8bdbab77b75b958f1124c394e4f270c07415e0da462eb4f80a8c9da055c5bb6a4b4afa1e72de11d4e53f384ff0081487fc2aacbe0fbc5720ecfccd7b02e964f6aa971a49f34e5467e9557158f29f126bd0f8bfc3f79bd7ec572007f25ce41239f94f706bce6cd0ab907eb5b3e23175a4ebb736920f2b631013a8da47f85664276b80475e87fa5064f5677df0dfc01af78db59b5b4b782e92de42332adb492ef19e40da0fa1eb5f527c30f839e27fd9ebc57a7f893579ada6d16694c37160242f3796c0e1b180320e3bd61fecc7fb4e5b785acecb43d521091c40209517a28ee6bd57e2ffc7fd2a78349bfb0d2e6d616749d62532b43e5b82815f18f981f9ab377d8d9256b96747fd8b34ab3f165f6a305da6a1a46a53fda99a69e48e58d0b1754550307af249e7d2bc0b5fb5b3f87de25d7f49bb9046ba7decb0a64f540df27e6b835f55f86bf6879bc63e158ef74dd2dad6f6dde0b416b34833348e189443dca8527e95f0f7c7bd4a6d7be2df8a972bf6837524b22a9c805211bb1ff007c1a237bea54acb63afd27e20e8d7b32c5bc293c0e6b6ee6e2c1e5c8bc85463a19003fcebe53967d8c4a920fa83cd4325c3eec97624f3c9ad0cee77ff1c5ec2faf6cafad23459028499918b6ecf2b93f9fe15e5c034a729f794e71eb5d578d2edeea1b48972d34c7cd64039e785181ed8fcea941e0dd660d213537d3e68ed5e41103229525bb601e7048233d32319a466f73b5f825a8e9769e29b59f56805cdaab0135b31dbe6274600fae2bdc7e2b7c3db2d12eed751f0d6b17b3f87aea313db45e696f2b7672bce791c67a7515f3878326846a296f72bc487606e8cbcf247239ee3240ce3276f5f479f5ed4f40556b699ae6c4032a05721914f462381860320e067040ced341a27a1f4c7c34d220f843f0475cf1c6af39134d6924f05bcce4ba8e800cf42e55718038c673dbe109bc593de6ab75a9dc4bbee6e7cdf36463cb1915831ffc78d7d3ff000dfe24c7e21f0a78ae5d72ff00ed33d86952bc76770c36ec11b82bb5bd70a0e0670c71eb5f18e3a8a95a3093dac6e042e09241e320e6993481df3d7002f4f418acd82628db792a7b7a5586700f2d8a7733b9e81e0ed36ea5bfb8d55d54dd222b42ae0903e6071ff7ca91f8d7d51e1fb5b61268f751881ed2e4c6b716edfbd055d88398d7058860c33db0a7bd78df87ade287fb41446a41db9ede83b7b1af79f08da89bc35a5a3c92b2085ce03953911020e4608e6253c11d5bd6866d146178e3e04695e31bd5d556296dae27b5855becb68c14b84033823217a0232718270d9c0f3bd43e14788f4cbdbdd26cacff00b6351b4da6e70cab0445b1b59a56c2e3a1ea59b8ce7f7883eadb756b7d66e2c56595adedbc9641248ce732cd2a9e4927e5118c01c649ddbb0bb7c5ecbc63a9fc41f17db685a94c21d2a785ef26b6b4cc624709bc2b1c925461540cf451df24ca6d8da479ff00c1bf0f6b1717face905224d4ef2c67305dba37905635dcb1f706325361c8ce10639001f07f8b5e036f02f8a668a18658b4db8667b75979688862b242c7bb46e1909efb73debf47d342b1f0f789f4d82c205820b29a4b68a35e14c26112f96d8ea0480303d4100835e01fb4d785f4f93e15f88ee9e10d756fac8b849c81bf734506e19c743e63123d68bdd9328e87c52095391fca977d36969989ffd9, 'Andrey Samoylov', 'https://www.facebook.com/graphememan', '', '', '2013-09-09 14:29:58', 1),
(5, 1, 0, '', 'CAADQjsffLFsBAPzYro4EfaiM8uf7AibTCIZBEJMs68XKUO5wz6NfJcOl3wc7JIzK4VHTHwH8R0gIe9vljSCh2dZCxyNh5AkOSPrQmhFewAAz9BzrjGudJVZAAuJSgEyrivXFwKuNteHfqjbYf3yXOGpXNxToXPdE8b8ZAnfZAgaCNLQsLBEz7pHZAbeJO60z4ZD', 100002453613778, 0xffd8ffe000104a46494600010100000100010000fffe003b43524541544f523a2067642d6a7065672076312e3020287573696e6720494a47204a50454720763830292c207175616c697479203d2039300affdb0043000302020302020303030304030304050805050404050a070706080c0a0c0c0b0a0b0b0d0e12100d0e110e0b0b1016101113141515150c0f171816141812141514ffdb00430103040405040509050509140d0b0d1414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414ffc0001108003c003c03012200021101031101ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc4001f0100030101010101010101010000000000000102030405060708090a0bffc400b51100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c03010002110311003f00fb268c51457ba79e4b6d6d2ddcc90c11b4b2b9c2a20c935d9e95f0b6f2e955efae16d41e7cb41bdbfc07eb5bbf0c748860d1bede5419e7661bcf50a0e303f104d769fe7ad7055af2527189d10a69abb3c87c65e0dff84792192d5279adc8fde4ee41c37a60018fad7295f434d124f13c722aba30c32b7208af0cf12e9c9a4ebb796a9c471bfc809e808c81f91ad285573f75ee4d48f2ea8cca28ff003d68e3fc9aeb310a28a2803d8fe1ceeff8452d43295c33e323a8dc4ff5ae9bf3ae67e1e5fa5ef862dd0366480989c63a7391fa115d37f9e95e354f8d9dd1f8507e75e2be3a2c7c577e48232cb8c8ea3681fd2bda4f4af16f1d5fa6a1e26bb68db747191103fee8c1fd735be1be366757630334b4da51fe78af48e50a297bd1f9d0076bf0bb556b7d566b12094b85dc08fe1651fd47f4af53ff003d6bcd3e1668fe6dd4fa8b861e58f2e3e3839ebfd3f3af4bfcebcaaf6f68ec75d3bf2ea67ebfa97f6468f757617798932173dfa0fd4d783bb991d9d8e598e49f7af7dd574f4d574eb8b490954990a923a8af06b9b792d2e2486452af1b15208c722ba30b6b3ee6756f74434a3fcf34b4576981d0e89e05d4f5b4594462daddba4b3719fa0ea6bbad1fe1b699a7157b806fa51ff3d06107fc07fc735d6850071c518af2a75e73f23b1538a1b1c6b1204450aa0602818029dfe7a518a315ce681fe7a566eade1eb0d6936dddb24add9f1861f4239ad234534dad509ab9e6dabfc2b923cbe9d72241ff003ca7e0fe0c38fd2b89bed2ef34db8682e6d9e2957a82bfc8f7af7ec5218d5b92a0d74c71138efa993a49ec7fffd9, 'Alexander Gufan', 'https://www.facebook.com/alexander.gufan', '', '', '2013-09-10 19:04:42', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE IF NOT EXISTS `authors` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `institution` int(10) unsigned NOT NULL,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` varchar(100) NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(100) NOT NULL,
  `ru_name` varchar(100) NOT NULL,
  `en_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ru_position` varchar(255) NOT NULL,
  `en_position` varchar(255) NOT NULL,
  `ru_address` text NOT NULL,
  `en_address` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `authors`
--

INSERT INTO `authors` (`id`, `institution`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`, `page_url`, `ru_name`, `en_name`, `email`, `ru_position`, `en_position`, `ru_address`, `en_address`) VALUES
(3, 2, 'Ленин', 'Ленин В.И.', 'Владимир Ильич Ульянов-Ленин', '', '', '', '', 'Ленин В.И.', 'Lenin V.I.', 'lenin@grapheme.ru', 'начальник', '', 'москва, кремль', '');

-- --------------------------------------------------------

--
-- Структура таблицы `institutions`
--

DROP TABLE IF EXISTS `institutions`;
CREATE TABLE IF NOT EXISTS `institutions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_small_title` varchar(100) NOT NULL,
  `en_small_title` varchar(100) NOT NULL,
  `ru_title` text NOT NULL,
  `ru_description` text NOT NULL,
  `en_title` text NOT NULL,
  `en_description` text NOT NULL,
  `ru_contacts` text NOT NULL,
  `en_contacts` text NOT NULL,
  `ru_site_link` varchar(100) NOT NULL,
  `en_site_link` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `institutions`
--

INSERT INTO `institutions` (`id`, `ru_small_title`, `en_small_title`, `ru_title`, `ru_description`, `en_title`, `en_description`, `ru_contacts`, `en_contacts`, `ru_site_link`, `en_site_link`) VALUES
(2, 'ИА ', 'IA "Grapheme"', '<p>\n   Интерактивное агентство "Графема"\n</p>', '', '', '', '', '', 'http://grapheme.ru', '');

-- --------------------------------------------------------

--
-- Структура таблицы `issues`
--

DROP TABLE IF EXISTS `issues`;
CREATE TABLE IF NOT EXISTS `issues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` varchar(100) NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(255) NOT NULL,
  `ru_title` varchar(100) NOT NULL,
  `en_title` varchar(100) NOT NULL,
  `number` int(10) unsigned NOT NULL,
  `month` tinyint(2) unsigned NOT NULL,
  `year` int(10) unsigned NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `issues`
--

INSERT INTO `issues` (`id`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`, `page_url`, `ru_title`, `en_title`, `number`, `month`, `year`, `date`) VALUES
(1, 'Выпуск №1. Январь 2013.', 'Выпуск №1. Январь 2013.', 'Выпуск №1. Январь 2013.', 'Issue #1, January 2013', 'Issue #1, January 2013', 'Issue #1, January 2013', '', 'Выпуск №1. Январь 2013.', 'Issue #1, January 2013', 1, 1, 2013, '2013-09-09 14:11:06');

-- --------------------------------------------------------

--
-- Структура таблицы `keywords`
--

DROP TABLE IF EXISTS `keywords`;
CREATE TABLE IF NOT EXISTS `keywords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `word_hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `keywords`
--

INSERT INTO `keywords` (`id`, `word`, `word_hash`) VALUES
(1, 'рыба', '0919b71f81c1c284af2ea8a41591b8ef'),
(2, 'duty through', '430af0ecc5ca87d31dda68ae9a72bc47'),
(3, 'saying through', '28d5940e1a59a03e8586b3bdec0f9779'),
(4, 'Lorem Ipsum', '6dbd01b4309de2c22b027eb35a3ce18b'),
(5, 'один', 'fc114849927fcbde0bde8042c274a17f'),
(6, 'два', 'c2c854ecd422455e737419840be146aa'),
(7, 'три', '5789d8642128e91502eec9e591403bcd');

-- --------------------------------------------------------

--
-- Структура таблицы `matching`
--

DROP TABLE IF EXISTS `matching`;
CREATE TABLE IF NOT EXISTS `matching` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `word` int(10) unsigned NOT NULL,
  `publication` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Дамп данных таблицы `matching`
--

INSERT INTO `matching` (`id`, `word`, `publication`) VALUES
(15, 1, 1),
(14, 2, 1),
(13, 3, 1),
(12, 4, 1),
(5, 5, 2),
(6, 6, 2),
(7, 7, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` text NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `ru_content` text NOT NULL,
  `en_content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`, `page_url`, `title`, `ru_content`, `en_content`) VALUES
(1, 'Фазовые переходы, упорядоченные состояния и новые материалы', 'Фазовые переходы, упорядоченные состояния и новые материалы', '', 'Phase transitions, ordered states and new materials', 'Phase transitions, ordered states and new materials', '', 'home', 'Главная страница', '<header>\n<h1 class="article-h1">Фазовые переходы, упорядоченные состояния и новые материалы</h1>\n<p class="desc">\n	        Журнал «Фазовые переходы, упорядоченные состояния и новые материалы» - первый в России электронный журнал,  посвященный широкому кругу вопросов из области физики конденсированных сред.  В нем публикуются результаты оригинальных исследований и обзоры, посвященные актуальным прикладным и  фундаментальным вопросам по темам:\n</p>\n</header>\n<p class="themes">\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки</li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики</li>\n	<li class="themes-item">Сверхпроводимость</li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур</li>\n	<li class="themes-item">Теория фазовых диаграмм</li>\n	<li class="themes-item">Свойства металлов и сплавов</li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации</li>\n	<li class="themes-item">Напряженные состояния и пластичность</li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности</li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности</li>\n	<li class="themes-item">Полимеры, жидкие кристаллы</li>\n	<li class="themes-item">Электронные свойства твердых тел</li>\n	<li class="themes-item">Атомные кластеры, фуллерены</li>\n</ul>\n<p class="freq-div">\n</p>\n<p>\n	        Периодичность журнала в свет - ежемесячно. Учредителем является Институт физики Южного федерального университета.\n</p>', '<header>\n<h1 class="article-h1">Phase transitions, ordered states and new materials</h1>\n<p class="desc">\n	          Журнал «Фазовые переходы, упорядоченные состояния и новые материалы» - первый в России электронный журнал,  посвященный широкому кругу вопросов из области физики конденсированных сред.  В нем публикуются результаты оригинальных исследований и обзоры, посвященные актуальным прикладным и  фундаментальным вопросам по темам:\n</p>\n</header>\n<p class="themes">\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки</li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики</li>\n	<li class="themes-item">Сверхпроводимость</li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур</li>\n	<li class="themes-item">Теория фазовых диаграмм</li>\n	<li class="themes-item">Свойства металлов и сплавов</li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации</li>\n	<li class="themes-item">Напряженные состояния и пластичность</li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности</li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности</li>\n	<li class="themes-item">Полимеры, жидкие кристаллы</li>\n	<li class="themes-item">Электронные свойства твердых тел</li>\n	<li class="themes-item">Атомные кластеры, фуллерены</li>\n</ul>\n<p class="freq-div">\n</p>\n<p>\n	          Периодичность журнала в свет - ежемесячно. Учредителем является Институт физики Южного федерального университета.\n</p>'),
(2, 'Выпуски', 'Выпуски', '', '', '', '', 'issues', 'Выпуски', '<header>\n<h1 class="article-h1">Выпуски</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>', '<header>\n<h1 class="article-h1">Issues</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>'),
(3, 'Информация для авторов', 'Информация для авторов', '', '', '', '', 'for-authors', 'Информация для авторов', '<header>\n<h1 class="article-h1">Информация для авторов</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section>\n<p class="themes">\n</p>\n<p class="theme-header">\n	 В нашем журнале публикуются оригинальные работы и обзоры по широкому спектру вопросов физики твердого тела. Основные рубрики:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки         </li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики         </li>\n	<li class="themes-item">Сверхпроводимость         </li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур         </li>\n	<li class="themes-item">Теория фазовых диаграмм         </li>\n	<li class="themes-item">Свойства металлов и сплавов         </li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации         </li>\n	<li class="themes-item">Напряженные состояния и пластичность         </li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности         </li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности         </li>\n	<li class="themes-item">Полимеры, жидкие кристаллы         </li>\n	<li class="themes-item">Электронные свойства твердых тел         </li>\n	<li class="themes-item">Атомные кластеры, фуллерены         </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	 Каждая статья должна сопровождаться следующей информацией:\n</p>\n<ol class="ord-list">\n	<li class="ord-item">         название статьи на русском и английском языках         </li>\n	<li class="ord-item">         информация о каждом из соавторов (см. ниже)         </li>\n	<li class="ord-item">         краткая аннотация на русском и английском языках         </li>\n	<li class="ord-item">         название рубрики журнала, к которой следует отнести статью          </li>\n	<li class="ord-item">         список ключевых слов на русском и английском языках (см. ниже).         </li>\n</ol>\n</section><section>\n<p class="theme-header">\n	 Информация об авторе или соавторах статьи должна быть подана в следующем виде:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">если в нашем журнале уже были опубликованы статьи с участием данного автора, достаточно указать это и предоставить фамилию, имя и отчество автора          </li>\n	<li class="themes-item">если автор публикуется у нас впервые, следует указать:\n	<ol class="ord-list">\n		<li class="ord-item">         фамилию, имя, отчество на русском языке, а также фамилию и имя на английском языке (для иностранных авторов – только на английском)         </li>\n		<li class="ord-item">         название учреждения, в котором работает автор, на русском и английском языках, а также ссылку на сайт учреждения (если он есть)         </li>\n		<li class="ord-item">         электронный адрес (если он есть) и информацию о том, согласен ли автор, чтобы этот электронный адрес был опубликован на его страничке нашего сайта         </li>\n	</ol>\n	</li>\n</ul>\n</section><section class="notes">\n<p class="theme-header">\n	 Замечания:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Словосочетание "ключевые слова" следует понимать традиционным для научных журналов способом. Так, "теория симметрии" или "рентгеноструктурный анализ" могут быть выбраны в качестве ключевых слов, несмотря на то, что с точки зрения филологии словами они не являются. При выборе самих ключевых слов для пометки статьи также следует руководствоваться традициями журналов по физике твердого тела. Кроме того, следует учитывать, что в электронном формате журнала ключевые слова служат для быстрого поиска статей по схожей тематике – таким образом, имеет определенный смысл в качестве ключевых слов выбирать то, что уже служит в таком качестве в тех статьях нашего журнала, которые, как Вам кажется, близки по тематике к Вашей статье.          </li>\n	<li class="themes-item">Электронный журнал “Фазовые переходы, упорядоченные состояния и новые материалы” индексируется в нескольких библиографических базах (база данных ФГУП НТЦ Информрегистр, электронная научная библиотека eLIBRARY.ru). Считаем нужным предупредить о том, что некоторые из этих баз не обладают технической возможностью хранить тексты формул в их естественном виде. Например, в случае, если в названии или аннотации статьи, опубликованной в нашем или любом другом журнале, встретится формула “PbFexNb1-xO3”, в базе Информрегистра она, по независящим от нас причинам, будет выглядеть как “PbFexNb1-xO3”.                 </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	 К оформлению текстов статей предъявляются следующие требования:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">редакция принимает только статьи, представленные в электронном виде, в формате doc или tex.          </li>\n	<li class="themes-item">рисунки также следует предоставлять в электронном виде, в любом из распространенных растровых форматов (jpg, gif, pcx, bmp…). Работа по переводу фотографий и снимков других видов в электронный вид, ложится на авторов статьи.          </li>\n	<li class="themes-item">рисунки должны быть выполнены таким образом, чтобы по возможности не нуждаться в последующем редактировании. Все важные детали должны быть изображены так, чтобы быть различимыми при изменении размеров рисунка до ширины в одну стандартную журнальную колонку или до ширины страницы А4. Желательно, чтобы надписи на всех рисунках, относящихся к одной статье, были сделаны в едином стиле.          </li>\n	<li class="themes-item">в случае использования формата doc, желательно, чтобы формулы были набраны в редакторе формул MathType.         </li>\n</ul>\n</section>', '<header>\n<h1 class="article-h1">Information for Authors</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section>\n<p class="themes">\n</p>\n<p class="theme-header">\n	  В нашем журнале публикуются оригинальные работы и обзоры по широкому спектру вопросов физики твердого тела. Основные рубрики:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки         </li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики         </li>\n	<li class="themes-item">Сверхпроводимость         </li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур         </li>\n	<li class="themes-item">Теория фазовых диаграмм         </li>\n	<li class="themes-item">Свойства металлов и сплавов         </li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации         </li>\n	<li class="themes-item">Напряженные состояния и пластичность         </li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности         </li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности         </li>\n	<li class="themes-item">Полимеры, жидкие кристаллы         </li>\n	<li class="themes-item">Электронные свойства твердых тел         </li>\n	<li class="themes-item">Атомные кластеры, фуллерены         </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	  Каждая статья должна сопровождаться следующей информацией:\n</p>\n<ol class="ord-list">\n	<li class="ord-item">         название статьи на русском и английском языках         </li>\n	<li class="ord-item">         информация о каждом из соавторов (см. ниже)         </li>\n	<li class="ord-item">         краткая аннотация на русском и английском языках         </li>\n	<li class="ord-item">         название рубрики журнала, к которой следует отнести статью          </li>\n	<li class="ord-item">         список ключевых слов на русском и английском языках (см. ниже).         </li>\n</ol>\n</section><section>\n<p class="theme-header">\n	  Информация об авторе или соавторах статьи должна быть подана в следующем виде:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">если в нашем журнале уже были опубликованы статьи с участием данного автора, достаточно указать это и предоставить фамилию, имя и отчество автора          </li>\n	<li class="themes-item">если автор публикуется у нас впервые, следует указать:\n	<ol class="ord-list">\n		<li class="ord-item">         фамилию, имя, отчество на русском языке, а также фамилию и имя на английском языке (для иностранных авторов – только на английском)         </li>\n		<li class="ord-item">         название учреждения, в котором работает автор, на русском и английском языках, а также ссылку на сайт учреждения (если он есть)         </li>\n		<li class="ord-item">         электронный адрес (если он есть) и информацию о том, согласен ли автор, чтобы этот электронный адрес был опубликован на его страничке нашего сайта         </li>\n	</ol>\n	</li>\n</ul>\n</section><section class="notes">\n<p class="theme-header">\n	  Замечания:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Словосочетание "ключевые слова" следует понимать традиционным для научных журналов способом. Так, "теория симметрии" или "рентгеноструктурный анализ" могут быть выбраны в качестве ключевых слов, несмотря на то, что с точки зрения филологии словами они не являются. При выборе самих ключевых слов для пометки статьи также следует руководствоваться традициями журналов по физике твердого тела. Кроме того, следует учитывать, что в электронном формате журнала ключевые слова служат для быстрого поиска статей по схожей тематике – таким образом, имеет определенный смысл в качестве ключевых слов выбирать то, что уже служит в таком качестве в тех статьях нашего журнала, которые, как Вам кажется, близки по тематике к Вашей статье.          </li>\n	<li class="themes-item">Электронный журнал “Фазовые переходы, упорядоченные состояния и новые материалы” индексируется в нескольких библиографических базах (база данных ФГУП НТЦ Информрегистр, электронная научная библиотека eLIBRARY.ru). Считаем нужным предупредить о том, что некоторые из этих баз не обладают технической возможностью хранить тексты формул в их естественном виде. Например, в случае, если в названии или аннотации статьи, опубликованной в нашем или любом другом журнале, встретится формула “PbFexNb1-xO3”, в базе Информрегистра она, по независящим от нас причинам, будет выглядеть как “PbFexNb1-xO3”.                 </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	  К оформлению текстов статей предъявляются следующие требования:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">редакция принимает только статьи, представленные в электронном виде, в формате doc или tex.          </li>\n	<li class="themes-item">рисунки также следует предоставлять в электронном виде, в любом из распространенных растровых форматов (jpg, gif, pcx, bmp…). Работа по переводу фотографий и снимков других видов в электронный вид, ложится на авторов статьи.          </li>\n	<li class="themes-item">рисунки должны быть выполнены таким образом, чтобы по возможности не нуждаться в последующем редактировании. Все важные детали должны быть изображены так, чтобы быть различимыми при изменении размеров рисунка до ширины в одну стандартную журнальную колонку или до ширины страницы А4. Желательно, чтобы надписи на всех рисунках, относящихся к одной статье, были сделаны в едином стиле.          </li>\n	<li class="themes-item">в случае использования формата doc, желательно, чтобы формулы были набраны в редакторе формул MathType.         </li>\n</ul>\n</section>'),
(4, 'Редколлегия', 'Редколлегия', '', '', '', '', 'editorial', 'Редколлегия', '<header>\n<h1 class="article-h1">Редколлегия</h1>\n</header><section class="editorial">\n<ul class="ed-position">\n	<li>\n	<p class="position-header">\n		 Главный редактор\n	</p>\n	<dl class="name-prof">\n		<dt>Сахненко Владимир Павлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		 Заместители главного редактора\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Панченко Евгений Михайлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		 Ученый секретарь\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		 Члены редакционного совета\n	</p>\n	<dl class="name-prof">\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n</ul>\n</section>', '<header>\n<h1 class="article-h1">Editorial</h1>\n</header><section class="editorial">\n<ul class="ed-position">\n	<li>\n	<p class="position-header">\n		  Главный редактор\n	</p>\n	<dl class="name-prof">\n		<dt>Сахненко Владимир Павлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		  Заместители главного редактора\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Панченко Евгений Михайлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		  Ученый секретарь\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		  Члены редакционного совета\n	</p>\n	<dl class="name-prof">\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n</ul>\n</section>'),
(5, 'Полезные ссылки', 'Полезные ссылки', '', '', '', '', 'usefull-links', 'Полезные ссылки', '<header>\n<h1 class="article-h1">Полезные ссылки</h1>\n</header><section class="useful-links">\n<dl>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n</dl>\n</section>', ''),
(6, 'Поиск', 'Поиск', '', 'Search', 'Search', '', 'search', 'Поиск', '<header>\n<h1 class="article-h1">Поиск</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>', '<header>\n<h1 class="article-h1">Search</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>'),
(7, 'Авторы', 'Авторы', '', '', '', '', 'authors', 'Авторы', '<header>\n				<h1 class="article-h1">Авторы</h1>\n				<div class="delicate-design-stroke"></div>\n			</header>', '<header>\n				<h1 class="article-h1">Authors</h1>\n				<div class="delicate-design-stroke"></div>\n			</header>'),
(8, 'Ключевые слова', 'Ключевые слова', '', '', '', '', 'keywords', 'Ключевые слова', '<header>\n<h1 class="article-h1">Ключевые слова</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>', '<header>\n<h1 class="article-h1">Keywords</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>'),
(9, 'Учреждения', 'Учреждения', '', '', '', '', 'institutions', 'Учреждения', '<header>\n<h1 class="article-h1">Учреждения</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section class="useful-links">\n<ol class="ord-list">\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n</ol>\n</section>', '<header>\n<h1 class="article-h1">Institutions</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section class="useful-links">\n<ol class="ord-list">\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n</ol>\n</section>'),
(10, 'Футтер', '', '', 'Footer', '', '', 'footer', 'Футтер', '<div class="footer-content">\n<p class="delicate-design-stroke">\n</p>\n<p class="issn">\n	   ISSN 2073-0373\n</p>\n<p class="issn">\n	<a class="no-clickble" href="">Свидетельство регистрации СМИ</a>\n</p>\n<p class="age">\n</p>\n<p>\n	   0+\n</p>\n</div>', '<div class="footer-content">\n<p class="delicate-design-stroke">\n</p>\n<p class="issn">\n	           ISSN 2073-0373\n</p>\n<p class="massm-sert">\n	<a href="#">Evidence of registration of mass media</a>\n</p>\n<p class="age">\n</p>\n<p>\n	  0+\n</p>\n</div>');

-- --------------------------------------------------------

--
-- Структура таблицы `page_resources`
--

DROP TABLE IF EXISTS `page_resources`;
CREATE TABLE IF NOT EXISTS `page_resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_url` varchar(100) NOT NULL,
  `number` int(10) unsigned NOT NULL,
  `caption` varchar(100) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `thumbnail` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `publications`
--

DROP TABLE IF EXISTS `publications`;
CREATE TABLE IF NOT EXISTS `publications` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` varchar(100) NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(255) NOT NULL,
  `ru_title` text NOT NULL,
  `en_title` text NOT NULL,
  `ru_annotation` text NOT NULL,
  `en_annotation` text NOT NULL,
  `ru_support` text NOT NULL,
  `en_support` text NOT NULL,
  `ru_bibliography` text NOT NULL,
  `en_bibliography` text NOT NULL,
  `ru_document` varchar(150) NOT NULL,
  `en_document` varchar(150) NOT NULL,
  `page` varchar(10) NOT NULL,
  `authors` varchar(255) NOT NULL,
  `issue` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `publications`
--

INSERT INTO `publications` (`id`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`, `page_url`, `ru_title`, `en_title`, `ru_annotation`, `en_annotation`, `ru_support`, `en_support`, `ru_bibliography`, `en_bibliography`, `ru_document`, `en_document`, `page`, `authors`, `issue`) VALUES
(1, 'Lorem Ipsum- это текст-', 'Lorem Ipsum- это текст-"рыба"', 'Lorem Ipsum- это текст-', 'de Finibus Bonorum et Malorum', 'de Finibus Bonorum et Malorum', 'de Finibus Bonorum et Malorum', 'lorem-ipsum-to-tekst-', 'Lorem Ipsum- это текст-', 'de Finibus Bonorum et Malorum', '<p>\n <strong>Lorem Ipsum</strong>- это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\n</p>', '<p>\n     Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?\n</p>', '<p>\n <strong>Lorem Ipsum</strong>- это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\n</p>', '<p>\n     Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?\n</p>', '<p>\n <strong>Lorem Ipsum</strong>- это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\n</p>', '<p>\n     Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?\n</p>', '2013/1/testrudocument1.pdf', '2013/1/testendocument1.pdf', '3', '', 1),
(2, 'Заголовок', 'Описание', 'Х1', '', '', '', 'nazvanie-publikacii', 'Название публикации', '', '<p>\n фбвк\n</p>', '', '<p>\n ффффф\n</p>', '', '<p >\n Библиографический список:\n</p>', '', '2013/2/testrudocument1.pdf', '', '', '2', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `publications_comments`
--

DROP TABLE IF EXISTS `publications_comments`;
CREATE TABLE IF NOT EXISTS `publications_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `publication` int(10) unsigned NOT NULL,
  `issue` int(10) unsigned NOT NULL,
  `account` int(10) unsigned NOT NULL,
  `comment` text NOT NULL,
  `parent` int(10) unsigned NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `publications_comments`
--

INSERT INTO `publications_comments` (`id`, `publication`, `issue`, `account`, `comment`, `parent`, `date`) VALUES
(1, 1, 1, 3, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 0, '2013-09-09 14:29:10'),
(2, 1, 1, 4, 'Ничего себе', 0, '2013-09-09 14:30:09'),
(3, 1, 1, 4, 'тестовый комментарий', 0, '2013-09-11 15:30:16');

-- --------------------------------------------------------

--
-- Структура таблицы `publications_resources`
--

DROP TABLE IF EXISTS `publications_resources`;
CREATE TABLE IF NOT EXISTS `publications_resources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `publication` int(11) NOT NULL,
  `issue` int(11) NOT NULL,
  `resource` text NOT NULL,
  `number` int(10) unsigned NOT NULL,
  `caption` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `publications_resources`
--

INSERT INTO `publications_resources` (`id`, `publication`, `issue`, `resource`, `number`, `caption`) VALUES
(1, 1, 1, '{"file_name":"document2.pdf","file_type":"application\\/pdf","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/ptosnm\\/download\\/2013\\/1\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/ptosnm\\/download\\/2013\\/1\\/document2.pdf","raw_name":"document2","orig_name":"document2.pdf","client_name":"Document2.pdf","file_ext":".pdf","file_size":157.69,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":""}', 0, ''),
(2, 1, 1, '{"file_name":"document1.pdf","file_type":"application\\/pdf","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/ptosnm\\/download\\/2013\\/1\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/ptosnm\\/download\\/2013\\/1\\/document1.pdf","raw_name":"document1","orig_name":"document1.pdf","client_name":"Document1.pdf","file_ext":".pdf","file_size":130.1,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":""}', 0, ''),
(3, 1, 1, '{"file_name":"linkin-park-angel-in-disguise.mp3","file_type":"audio\\/mpeg","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/ptosnm\\/download\\/2013\\/1\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/ptosnm\\/download\\/2013\\/1\\/linkin-park-angel-in-disguise.mp3","raw_name":"linkin-park-angel-in-disguise","orig_name":"linkin-park-angel-in-disguise.mp3","client_name":"Linkin Park - Angel in disguise.mp3","file_ext":".mp3","file_size":5478.61,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":""}', 0, ''),
(4, 2, 2, '{"file_name":"drawspace-b02.pdf","file_type":"application\\/pdf","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/ptosnm\\/download\\/2013\\/2\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/ptosnm\\/download\\/2013\\/2\\/drawspace-b02.pdf","raw_name":"drawspace-b02","orig_name":"drawspace-b02.pdf","client_name":"drawspace-b02.pdf","file_ext":".pdf","file_size":412.56,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":""}', 0, ''),
(5, 1, 1, '{"file_name":"koala.jpg","file_type":"image\\/jpeg","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/ptosnm\\/download\\/2013\\/1\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/ptosnm\\/download\\/2013\\/1\\/koala.jpg","raw_name":"koala","orig_name":"koala.jpg","client_name":"Koala.jpg","file_ext":".jpg","file_size":762.53,"is_image":true,"image_width":1024,"image_height":768,"image_type":"jpeg","image_size_str":"width=\\"1024\\" height=\\"768\\""}', 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('c977bfbe13b0054541a342e938aa8a2c', '83.102.160.18', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.57 Safari/537.36', 1379006306, ''),
('989de2c0bde007d1c02d296cfac8d60b', '5.166.232.83', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_4) AppleWebKit/536.30.1 (KHTML, like Gecko) Version/6.0.5 Safari/536.30.1', 1379006325, '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
