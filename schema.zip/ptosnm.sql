-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Сен 09 2013 г., 15:11
-- Версия сервера: 5.1.40-community
-- Версия PHP: 5.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `ptosnm`
--
CREATE DATABASE IF NOT EXISTS `ptosnm` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `ptosnm`;

-- --------------------------------------------------------

--
-- Структура таблицы `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `vkid` int(11) NOT NULL,
  `vk_access_token` text NOT NULL,
  `facebook_access_token` text NOT NULL,
  `facebookid` bigint(20) NOT NULL,
  `photo` mediumblob NOT NULL,
  `name` varchar(100) NOT NULL,
  `link` varchar(200) NOT NULL,
  `login` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `signdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `email` (`login`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `accounts`
--

INSERT INTO `accounts` (`id`, `group`, `vkid`, `vk_access_token`, `facebook_access_token`, `facebookid`, `photo`, `name`, `link`, `login`, `password`, `signdate`, `active`) VALUES
(2, 1, 0, '', '', 0, '', '', '', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '2013-09-03 08:28:59', 1),
(4, 1, 23757724, 'ab4d0db73b40cd01072823f5355a05b25797ac364c1bac81c5169f1aa0b4b7fd2d7b0c260d105060b7c49', '', 0, 0xffd8ffe000104a46494600010101004800480000ffdb00430002020202020102020202030202030306040303030307050504060807090808070808090a0d0b090a0c0a08080b0f0b0c0d0e0e0f0e090b1011100e110d0e0e0effdb004301020303030303070404070e0908090e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0effc00011080032003203012200021101031101ffc4001d000002020203010000000000000000000000070506030801020409ffc40032100001030302050206010305000000000001020304000511061207212231411351081432617181152333a191b1c1d1d2ffc4001a010100030101010000000000000000000003010204050006ffc400241100030002010206030000000000000000000102111241313213212251529161a1f0ffda000c03010002110311003f00faeacc3610b2af452143c8c57b76236e124e7ee6b07cd2929e781f91de813078403f8afa1abaa79672e6664cdb569ce120feeb03855b7fb78fdd2db8adc58b0f09784133596a0b7dcee36e8ef21b718b5b0975eeacf57529290900124950f619240a96d23aeac7ae7853a7f58d894f0b45e60a25c5129bf4dd4a559e4b4e4e1408208c91cb9122895e6b5e46d7d3b70589e563391fe6a065ad209c8e55eb93359c1c287fad56664d6f07a88fc1ad1390d9d8b8dee3ca8aae197d47abcd14a1e4d598361d536f94e085c64d7b0d6a5254af56f01e04a7b1eb695e3c76fb57170b5f12a4db57ea71f755b7190f87f7ad1172829c293d5b13d2319c76e67351eabeba54b758b8bdbbb6d694caf711e303abf551d76ba7f3b61b9591e74bcd4c8cb65f1eb290b295a4a558e9232013e71cbb57229c8b28d16e377c545c53135b70da3f11afbae214679519d5dc50c7c9baf2569515b6a6f2a504ab790790ca538e44d2eb417c74f1934b59f4d69c3a859b7e9480d22121a876e42951d948500b09247a8a1bb71c905440c9ad68e27682bae87e21de74d5e265bd69d3c86a3c6318250e4d61c2a7197f681959c398528f50c00720034bdb1ff2099899f01b65e5b4af4c32e6d5174b892ded083f512158fd8ac6ab1595d4dd86e14f1d4fbc1a775e71daeba6ad5a9ac5c67b4eabb14c869723ae469f4290f248c6f3b4852579ee3c104115323897c7e8f19b12aeba3ee4a03eb559df68b833e76af97ea935c2fb2dc3879f0ffa434522cc2749876ddd2de4cf0017dc5171d4e40cf252881dfe9ef56595a9a1b3b62ca663c07081ea09325c2a48f70af4f99ec3bd22bfcbfb667d516c5717f8ddea2b10b46633e112e8aa12b525842c855c6315679ff587fdd14be2bf97eca688cc358dda3a90836f8f7359495213eb84280f6208eff7ae19d68fc98ab32ed2dc6460e14ccc43d8f7cede600ad7799298964225c860495a13d3f30528efc9180afbf8ac6cfca429cda1bbd22df28614b6a3bfb129c72007b72279f9accedb6225e42d7e2cac16093a6d3afe0befaef4fbac409cd38e25c6434da1c5214396edddc1c9c631ca937c02d17025fc47c787aaad21f5c48ea9b0d01c29087d971b52558040581bbe92707cd327e202f51a4f021f889d40ab8add9cda91196f17776ddc147b74e33f6efe6a8bc35d5506e5f10b3e6317336f4fc82d888eb4d86cad6e7a6140249e43a55e73803de8b64d0c93c1bef71d55298bb2dc950a33cdb649052d290e13e0f9c7e01a8095c40b6b8cacaa5986e038525718af979fa4a4ff00b8a5849d497fb44a0e7f2c67ad6a202a4250403e738ff9e43b547bfaaae4544dca14753bbba762b6a943f18da7f745bd22303215abac4b714b377592a3927e4dcffcd15461a96da1007ca5c7b7864e3fc5156debdffbec8c087b05cee5238d109a7ee125e68bae82871f5281013c8609a91b62952177290fa8bcf9ba14971c3b95819c0c9e78a28a97da5f930f111291c0ad44424652df238edcd34a4d26db6d424a9a6d2d93aab69284e3212c28a47e064e28a28e7b112877599e75fb425b7dd5bcded4a76b8a2a18c76c1abcc5421cb7c9f51217b15846e19da36f61ed45157ae850ec86dbf493d09eded451457893ffd9, 'Владимир Харсеев', 'http://vk.com/vkharseev', '', '', '2013-09-09 11:08:09', 1),
(5, 1, 0, '', 'CAADQjsffLFsBAM71YG8Pv6M5rrFjR7hzyLISeblBLZBzZB9ZAcbcrTAgFJmDoX7CMrKNuZAl1A6XWZC3eWmECnimIvEiJQZCU21eocWa33fJjDCXeZCi7IZATQv6OKqi64tHKwvVkQKADyzZAobZAoWfA1iDDBgZAr90WSxiJFDWxIdI1aplUZCZBm4rM', 100001912017351, 0xffd8ffe000104a46494600010100000100010000fffe003b43524541544f523a2067642d6a7065672076312e3020287573696e6720494a47204a50454720763632292c207175616c697479203d2039300affdb0043000302020302020303030304030304050805050404050a070706080c0a0c0c0b0a0b0b0d0e12100d0e110e0b0b1016101113141515150c0f171816141812141514ffdb00430103040405040509050509140d0b0d1414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414ffc0001108003c003c03012200021101031101ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc4001f0100030101010101010101010000000000000102030405060708090a0bffc400b51100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c03010002110311003f00e9db4786e2e7c9865b887bef29c67f3eb56f56d59f42b00d7db6fad91c07b8475530293cbbe4e368ebcf3c1e0d6641ad096da38d525da3243f9a091cf72ca4feb5f2ff00c7cf8cb3789eedf43d36e8be996cc7cc917004f274edd54738fcfd2b16fa1318b91d8f8f3f69486daecdbf86c2dc46387bb961da1bb1c2e46071dff2ac0d1bf683d684e1bceb7607960d1124fe1915f3ccd72c31fbc65cf714f8ef660c0f9aacdfdd3d4d4385fa9d0b956963ed6d17e37e97e2058e1d46d15ee0281ca6df4e9bba7e7debac6f167852e6686d7ecb8b998657612b9fc41c57c3ba67896e555638eea48c28e53382bf4aecfc2de3ebfd2e65492ebed300f9bf7c323b7ebef593f691d8ae48cbc8fafe3b5d3040311bc4081c072483c7739a8058c049da1d973c13839fe55ca7c3ef1fe81afe966d2ee67b4bd087cb904831fa86fd41fa1af4236cd7914320b8541b00c2caac0fbe768cfe007d2b5854525a1cd383868cf3ff008ffe2db9f0bfc2fd5668a511dccea2d14a93905ce0953ebb771af8416f37c85082173d6bea2fdae75bbabdf0de951471edb792f98b843bb2c11827381d41638c7e75f375f784b58d26167bab47842c82370704a3150d823e8452bd9ea74d384a51bc5140a46f9ebc7a9a9ad2dda595563da49fe11c558b2d2c5d4bb230ce38ced1c9af46f877f0ba6d535e8e7bab696d74e8c757cab3b7a0a52a8a275d2a2ea338093469e360b243993dba8abda66817b74c123958ae70236e7debe939be14c5340b0dadb4496c47ef2695816fc07afb935e85e01f82ba1e936f15c359b48fbf7618861f88eff4ae478976d8ed5834ba9f2f3787fc47a3cb6d6f6fbe3dd1aca06304024e08fcabe88f016ababdb786edd3527f327ce418e366017030322b6fe30f81e7bef13f859f4b8483323a4bb06005578ce0fe0cd5d6e95acdce8f662d92081406672a17214b31240f619c0fa5141ce7ef33cfc55a9b513c5ff684d3859f86749ba9712456bacdb4d2f1918cb03cfe349adf872d355b06b15813ceb990caf2ff0019709c11ec0003f0ab7fb5bf87ad740f8711c4f7534d76f731b23e308cc38200f4009e4d50f03788edf57f07da1d41d535089029761ceec6d0411ea3fad6d8b8385b9b73ab2ca89c2503ce3e1e780dacf5ed523ba848588848e500ed6e739fe55ea9acda5d59da2cb6e245c720c2327f2a65826cb80c06727b77aef34858e550b22ab03d335e74e5cf2d4f529c545591e6d1dcebda725bce97f73146cfb5e3302b9e99c9f988c1e9ebd6bd3edbc4f7fa67847fb402bdecaaea81615e599b38c8ec38a4d7f48d3a1b73b843083d70315a1f0d92deef53fecf7804b6770be514906413d5783fed01f9537172348ae54c6787757d7af6d24935f48e38b7936e92dbe0920e372f5c8f71e95d545e20468d7cfb4b1ba900c191e0393f9835d06a11593dac31a416cc96c9b157cb1945e4e07e24d60cf716a8fb7fb1da5c01f3c6ec80fe1b857a54147911f278b9395577337e3cfc2483e35780634b09c0bfb090ddda91f7653b4828dec41ebd8e2be73d02c25b2d09ede5431dcc5fbb911860ab29c1c8ec6bec1f0eafd82ea7f24954f3550c64e5486ce78af12f8b3a4db699e3dbafb3a6c172a25917b16c91fd3f535ae612ba53ea6d964ecdd3385d36f0070878fc6bb7d0ae32bd33b4715e596d72ff00da1769c058a631ae0638c0ff001aedf479dd1700fb5784f53de8bb1a7a9ea305d48d14d711238ed248015e7838fc2ba3f06bceb748e6fe011aed78ca152ec41c6383ebed5872d95bce80cb0c727cbfc6a0d777f07638ae6fad52482131add46de584015b6f20103af4ad23aa51475cda853727d0ec3c59f0bbc4fa4e9a6f9a1325b3223cb3d9c9978c70483dc60f5e31d79ae4609dde3dc24521893f31e9cf4e057d7093369f756b14276c73286287a2f1dbff00af9acdbff84be11f105d3dedde8b0fda1cfced03bc218f52484600939e4e326bdba718b5cb1e87c34aa39b6e5d4fffd9, 'Владимир Харсеев', 'https://www.facebook.com/profile.php?id=100001912017351', '', '', '2013-09-09 11:08:56', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE IF NOT EXISTS `authors` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `institution` int(10) unsigned NOT NULL,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` varchar(100) NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(100) NOT NULL,
  `ru_name` varchar(100) NOT NULL,
  `en_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ru_position` varchar(255) NOT NULL,
  `en_position` varchar(255) NOT NULL,
  `ru_address` text NOT NULL,
  `en_address` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `authors`
--

INSERT INTO `authors` (`id`, `institution`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`, `page_url`, `ru_name`, `en_name`, `email`, `ru_position`, `en_position`, `ru_address`, `en_address`) VALUES
(1, 1, 'Харсеев В.А.', 'Харсеев В.А.', '', 'Kharseev V.', 'Kharseev V.', '', '', 'Харсеев В.А.', 'Kharseev V.', 'vkharseev@gmail.com', 'Доктор физико-математических наук', 'Doctor of Physical and Mathematical Sciences', 'Ростов на дону', 'Rostov on Don'),
(2, 3, 'Самойлов А.Г.', 'Самойлов А.Г.', '', 'Samoilov A.', 'Samoilov A.', '', '', 'Самойлов А.Г.', 'Samoilov A.', 'andrew.samoilov@gmail.com', 'Начальство', 'Director', 'Ростов-на-Дону, ул.Суворова, 52а', 'Rostov-on-Don, Suvorova 52a');

-- --------------------------------------------------------

--
-- Структура таблицы `institutions`
--

DROP TABLE IF EXISTS `institutions`;
CREATE TABLE IF NOT EXISTS `institutions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_small_title` varchar(100) NOT NULL,
  `en_small_title` varchar(100) NOT NULL,
  `ru_title` text NOT NULL,
  `ru_description` text NOT NULL,
  `en_title` text NOT NULL,
  `en_description` text NOT NULL,
  `ru_contacts` text NOT NULL,
  `en_contacts` text NOT NULL,
  `site_link` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `institutions`
--

INSERT INTO `institutions` (`id`, `ru_small_title`, `en_small_title`, `ru_title`, `ru_description`, `en_title`, `en_description`, `ru_contacts`, `en_contacts`, `site_link`) VALUES
(1, 'ВКГТУ', 'VKGTU', ' <span class="gray">ВКГТУ</span>  (Восточно-Казанский технический Университет им Д.Серикбаева)', '', '<p>\n  <span class="gray">VKGTU</span>  (Восточно-Казанский технический Университет им Д.Серикбаева)\n</p>', '', '', '', 'http://google.com'),
(3, 'КДПУ', 'KDPU', '<p>\n КДПУ\n</p>', '', '<p>\n KDPU\n</p>', '', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `issues`
--

DROP TABLE IF EXISTS `issues`;
CREATE TABLE IF NOT EXISTS `issues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` varchar(100) NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(255) NOT NULL,
  `ru_title` varchar(100) NOT NULL,
  `en_title` varchar(100) NOT NULL,
  `number` int(10) unsigned NOT NULL,
  `month` tinyint(2) unsigned NOT NULL,
  `year` int(10) unsigned NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `issues`
--

INSERT INTO `issues` (`id`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`, `page_url`, `ru_title`, `en_title`, `number`, `month`, `year`, `date`) VALUES
(1, 'Выпуск №1 Январь 2013', 'Выпуск №1 Январь 2013', '', 'Issue #1 January 2013', 'Issue #1 January 2013', '', '', 'Выпуск №1 Январь 2013', 'Issue #1 January 2013', 1, 1, 2013, '2013-09-05 15:26:22'),
(2, 'Выпуск №2 Февраль 2013', 'Выпуск №2 Февраль 2013', '', 'Issue #1 Fabruary 2013', 'Issue #1 Fabruary 2013', '', '', 'Выпуск №2 Февраль 2013', 'Issue #1 Fabruary 2013', 2, 2, 2013, '2013-09-05 15:34:16');

-- --------------------------------------------------------

--
-- Структура таблицы `keywords`
--

DROP TABLE IF EXISTS `keywords`;
CREATE TABLE IF NOT EXISTS `keywords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `word_hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `keywords`
--

INSERT INTO `keywords` (`id`, `word`, `word_hash`) VALUES
(1, 'топологические изоляторы', 'c6a929d5230d3b58bcb95e0098f6dac7'),
(2, 'заряженные частицы', '0d83e749a83df16a95e86b08dfb07cd3'),
(3, 'английский перевод', 'a4915273be391c75e39ef5faa3c9c3dd');

-- --------------------------------------------------------

--
-- Структура таблицы `matching`
--

DROP TABLE IF EXISTS `matching`;
CREATE TABLE IF NOT EXISTS `matching` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `word` int(10) unsigned NOT NULL,
  `publication` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Дамп данных таблицы `matching`
--

INSERT INTO `matching` (`id`, `word`, `publication`) VALUES
(17, 1, 1),
(16, 2, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` text NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `ru_content` text NOT NULL,
  `en_content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`, `page_url`, `title`, `ru_content`, `en_content`) VALUES
(1, 'Фазовые переходы, упорядоченные состояния и новые материалы', 'Фазовые переходы, упорядоченные состояния и новые материалы', '', 'Phase transitions, ordered states and new materials', 'Phase transitions, ordered states and new materials', '', 'home', 'Главная страница', '<header>\n<h1 class="article-h1">Фазовые переходы, упорядоченные состояния и новые материалы</h1>\n<p class="desc">\n	        Журнал «Фазовые переходы, упорядоченные состояния и новые материалы» - первый в России электронный журнал,  посвященный широкому кругу вопросов из области физики конденсированных сред.  В нем публикуются результаты оригинальных исследований и обзоры, посвященные актуальным прикладным и  фундаментальным вопросам по темам:\n</p>\n</header>\n<p class="themes">\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки</li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики</li>\n	<li class="themes-item">Сверхпроводимость</li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур</li>\n	<li class="themes-item">Теория фазовых диаграмм</li>\n	<li class="themes-item">Свойства металлов и сплавов</li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации</li>\n	<li class="themes-item">Напряженные состояния и пластичность</li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности</li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности</li>\n	<li class="themes-item">Полимеры, жидкие кристаллы</li>\n	<li class="themes-item">Электронные свойства твердых тел</li>\n	<li class="themes-item">Атомные кластеры, фуллерены</li>\n</ul>\n<p class="freq-div">\n</p>\n<p>\n	        Периодичность журнала в свет - ежемесячно. Учредителем является Институт физики Южного федерального университета.\n</p>', '<header>\n<h1 class="article-h1">Phase transitions, ordered states and new materials</h1>\n<p class="desc">\n	          Журнал «Фазовые переходы, упорядоченные состояния и новые материалы» - первый в России электронный журнал,  посвященный широкому кругу вопросов из области физики конденсированных сред.  В нем публикуются результаты оригинальных исследований и обзоры, посвященные актуальным прикладным и  фундаментальным вопросам по темам:\n</p>\n</header>\n<p class="themes">\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки</li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики</li>\n	<li class="themes-item">Сверхпроводимость</li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур</li>\n	<li class="themes-item">Теория фазовых диаграмм</li>\n	<li class="themes-item">Свойства металлов и сплавов</li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации</li>\n	<li class="themes-item">Напряженные состояния и пластичность</li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности</li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности</li>\n	<li class="themes-item">Полимеры, жидкие кристаллы</li>\n	<li class="themes-item">Электронные свойства твердых тел</li>\n	<li class="themes-item">Атомные кластеры, фуллерены</li>\n</ul>\n<p class="freq-div">\n</p>\n<p>\n	          Периодичность журнала в свет - ежемесячно. Учредителем является Институт физики Южного федерального университета.\n</p>'),
(2, 'Выпуски', 'Выпуски', '', '', '', '', 'issues', 'Выпуски', '<header>\n<h1 class="article-h1">Выпуски</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>', '<header>\n<h1 class="article-h1">Issues</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>'),
(3, 'Информация для авторов', 'Информация для авторов', '', '', '', '', 'for-authors', 'Информация для авторов', '<header>\n<h1 class="article-h1">Информация для авторов</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section>\n<p class="themes">\n</p>\n<p class="theme-header">\n	 В нашем журнале публикуются оригинальные работы и обзоры по широкому спектру вопросов физики твердого тела. Основные рубрики:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки         </li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики         </li>\n	<li class="themes-item">Сверхпроводимость         </li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур         </li>\n	<li class="themes-item">Теория фазовых диаграмм         </li>\n	<li class="themes-item">Свойства металлов и сплавов         </li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации         </li>\n	<li class="themes-item">Напряженные состояния и пластичность         </li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности         </li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности         </li>\n	<li class="themes-item">Полимеры, жидкие кристаллы         </li>\n	<li class="themes-item">Электронные свойства твердых тел         </li>\n	<li class="themes-item">Атомные кластеры, фуллерены         </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	 Каждая статья должна сопровождаться следующей информацией:\n</p>\n<ol class="ord-list">\n	<li class="ord-item">         название статьи на русском и английском языках         </li>\n	<li class="ord-item">         информация о каждом из соавторов (см. ниже)         </li>\n	<li class="ord-item">         краткая аннотация на русском и английском языках         </li>\n	<li class="ord-item">         название рубрики журнала, к которой следует отнести статью          </li>\n	<li class="ord-item">         список ключевых слов на русском и английском языках (см. ниже).         </li>\n</ol>\n</section><section>\n<p class="theme-header">\n	 Информация об авторе или соавторах статьи должна быть подана в следующем виде:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">если в нашем журнале уже были опубликованы статьи с участием данного автора, достаточно указать это и предоставить фамилию, имя и отчество автора          </li>\n	<li class="themes-item">если автор публикуется у нас впервые, следует указать:\n	<ol class="ord-list">\n		<li class="ord-item">         фамилию, имя, отчество на русском языке, а также фамилию и имя на английском языке (для иностранных авторов – только на английском)         </li>\n		<li class="ord-item">         название учреждения, в котором работает автор, на русском и английском языках, а также ссылку на сайт учреждения (если он есть)         </li>\n		<li class="ord-item">         электронный адрес (если он есть) и информацию о том, согласен ли автор, чтобы этот электронный адрес был опубликован на его страничке нашего сайта         </li>\n	</ol>\n	</li>\n</ul>\n</section><section class="notes">\n<p class="theme-header">\n	 Замечания:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Словосочетание "ключевые слова" следует понимать традиционным для научных журналов способом. Так, "теория симметрии" или "рентгеноструктурный анализ" могут быть выбраны в качестве ключевых слов, несмотря на то, что с точки зрения филологии словами они не являются. При выборе самих ключевых слов для пометки статьи также следует руководствоваться традициями журналов по физике твердого тела. Кроме того, следует учитывать, что в электронном формате журнала ключевые слова служат для быстрого поиска статей по схожей тематике – таким образом, имеет определенный смысл в качестве ключевых слов выбирать то, что уже служит в таком качестве в тех статьях нашего журнала, которые, как Вам кажется, близки по тематике к Вашей статье.          </li>\n	<li class="themes-item">Электронный журнал “Фазовые переходы, упорядоченные состояния и новые материалы” индексируется в нескольких библиографических базах (база данных ФГУП НТЦ Информрегистр, электронная научная библиотека eLIBRARY.ru). Считаем нужным предупредить о том, что некоторые из этих баз не обладают технической возможностью хранить тексты формул в их естественном виде. Например, в случае, если в названии или аннотации статьи, опубликованной в нашем или любом другом журнале, встретится формула “PbFexNb1-xO3”, в базе Информрегистра она, по независящим от нас причинам, будет выглядеть как “PbFexNb1-xO3”.                 </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	 К оформлению текстов статей предъявляются следующие требования:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">редакция принимает только статьи, представленные в электронном виде, в формате doc или tex.          </li>\n	<li class="themes-item">рисунки также следует предоставлять в электронном виде, в любом из распространенных растровых форматов (jpg, gif, pcx, bmp…). Работа по переводу фотографий и снимков других видов в электронный вид, ложится на авторов статьи.          </li>\n	<li class="themes-item">рисунки должны быть выполнены таким образом, чтобы по возможности не нуждаться в последующем редактировании. Все важные детали должны быть изображены так, чтобы быть различимыми при изменении размеров рисунка до ширины в одну стандартную журнальную колонку или до ширины страницы А4. Желательно, чтобы надписи на всех рисунках, относящихся к одной статье, были сделаны в едином стиле.          </li>\n	<li class="themes-item">в случае использования формата doc, желательно, чтобы формулы были набраны в редакторе формул MathType.         </li>\n</ul>\n</section>', '<header>\n<h1 class="article-h1">Information for Authors</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section>\n<p class="themes">\n</p>\n<p class="theme-header">\n	  В нашем журнале публикуются оригинальные работы и обзоры по широкому спектру вопросов физики твердого тела. Основные рубрики:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки         </li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики         </li>\n	<li class="themes-item">Сверхпроводимость         </li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур         </li>\n	<li class="themes-item">Теория фазовых диаграмм         </li>\n	<li class="themes-item">Свойства металлов и сплавов         </li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации         </li>\n	<li class="themes-item">Напряженные состояния и пластичность         </li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности         </li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности         </li>\n	<li class="themes-item">Полимеры, жидкие кристаллы         </li>\n	<li class="themes-item">Электронные свойства твердых тел         </li>\n	<li class="themes-item">Атомные кластеры, фуллерены         </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	  Каждая статья должна сопровождаться следующей информацией:\n</p>\n<ol class="ord-list">\n	<li class="ord-item">         название статьи на русском и английском языках         </li>\n	<li class="ord-item">         информация о каждом из соавторов (см. ниже)         </li>\n	<li class="ord-item">         краткая аннотация на русском и английском языках         </li>\n	<li class="ord-item">         название рубрики журнала, к которой следует отнести статью          </li>\n	<li class="ord-item">         список ключевых слов на русском и английском языках (см. ниже).         </li>\n</ol>\n</section><section>\n<p class="theme-header">\n	  Информация об авторе или соавторах статьи должна быть подана в следующем виде:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">если в нашем журнале уже были опубликованы статьи с участием данного автора, достаточно указать это и предоставить фамилию, имя и отчество автора          </li>\n	<li class="themes-item">если автор публикуется у нас впервые, следует указать:\n	<ol class="ord-list">\n		<li class="ord-item">         фамилию, имя, отчество на русском языке, а также фамилию и имя на английском языке (для иностранных авторов – только на английском)         </li>\n		<li class="ord-item">         название учреждения, в котором работает автор, на русском и английском языках, а также ссылку на сайт учреждения (если он есть)         </li>\n		<li class="ord-item">         электронный адрес (если он есть) и информацию о том, согласен ли автор, чтобы этот электронный адрес был опубликован на его страничке нашего сайта         </li>\n	</ol>\n	</li>\n</ul>\n</section><section class="notes">\n<p class="theme-header">\n	  Замечания:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Словосочетание "ключевые слова" следует понимать традиционным для научных журналов способом. Так, "теория симметрии" или "рентгеноструктурный анализ" могут быть выбраны в качестве ключевых слов, несмотря на то, что с точки зрения филологии словами они не являются. При выборе самих ключевых слов для пометки статьи также следует руководствоваться традициями журналов по физике твердого тела. Кроме того, следует учитывать, что в электронном формате журнала ключевые слова служат для быстрого поиска статей по схожей тематике – таким образом, имеет определенный смысл в качестве ключевых слов выбирать то, что уже служит в таком качестве в тех статьях нашего журнала, которые, как Вам кажется, близки по тематике к Вашей статье.          </li>\n	<li class="themes-item">Электронный журнал “Фазовые переходы, упорядоченные состояния и новые материалы” индексируется в нескольких библиографических базах (база данных ФГУП НТЦ Информрегистр, электронная научная библиотека eLIBRARY.ru). Считаем нужным предупредить о том, что некоторые из этих баз не обладают технической возможностью хранить тексты формул в их естественном виде. Например, в случае, если в названии или аннотации статьи, опубликованной в нашем или любом другом журнале, встретится формула “PbFexNb1-xO3”, в базе Информрегистра она, по независящим от нас причинам, будет выглядеть как “PbFexNb1-xO3”.                 </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	  К оформлению текстов статей предъявляются следующие требования:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">редакция принимает только статьи, представленные в электронном виде, в формате doc или tex.          </li>\n	<li class="themes-item">рисунки также следует предоставлять в электронном виде, в любом из распространенных растровых форматов (jpg, gif, pcx, bmp…). Работа по переводу фотографий и снимков других видов в электронный вид, ложится на авторов статьи.          </li>\n	<li class="themes-item">рисунки должны быть выполнены таким образом, чтобы по возможности не нуждаться в последующем редактировании. Все важные детали должны быть изображены так, чтобы быть различимыми при изменении размеров рисунка до ширины в одну стандартную журнальную колонку или до ширины страницы А4. Желательно, чтобы надписи на всех рисунках, относящихся к одной статье, были сделаны в едином стиле.          </li>\n	<li class="themes-item">в случае использования формата doc, желательно, чтобы формулы были набраны в редакторе формул MathType.         </li>\n</ul>\n</section>'),
(4, 'Редколлегия', 'Редколлегия', '', '', '', '', 'editorial', 'Редколлегия', '<header>\n<h1 class="article-h1">Редколлегия</h1>\n</header><section class="editorial">\n<ul class="ed-position">\n	<li>\n	<p class="position-header">\n		Главный редактор\n	</p>\n	<dl class="name-prof">\n		<dt>Сахненко Владимир Павлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		Заместители главного редактора\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Панченко Евгений Михайлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		Ученый секретарь\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		Члены редакционного совета\n	</p>\n	<dl class="name-prof">\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n</ul>\n</section>', '<header>\n<h1 class="article-h1">Editorial</h1>\n</header><section class="editorial">\n<ul class="ed-position">\n	<li>\n	<p class="position-header">\n		 Главный редактор\n	</p>\n	<dl class="name-prof">\n		<dt>Сахненко Владимир Павлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		 Заместители главного редактора\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Панченко Евгений Михайлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		 Ученый секретарь\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		 Члены редакционного совета\n	</p>\n	<dl class="name-prof">\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n</ul>\n</section>'),
(5, 'Полезные ссылки', 'Полезные ссылки', '', '', '', '', 'usefull-links', 'Полезные ссылки', '<header>\n<h1 class="article-h1">Полезные ссылки</h1>\n</header><section class="useful-links">\n<dl>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n</dl>\n</section>', ''),
(6, 'Поиск', 'Поиск', '', 'Search', 'Search', '', 'search', 'Поиск', '<header>\n<h1 class="article-h1">Поиск</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>', '<header>\n<h1 class="article-h1">Search</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>'),
(7, 'Авторы', 'Авторы', '', '', '', '', 'authors', 'Авторы', '<header>\n				<h1 class="article-h1">Авторы</h1>\n				<div class="delicate-design-stroke"></div>\n			</header>', '<header>\n				<h1 class="article-h1">Authors</h1>\n				<div class="delicate-design-stroke"></div>\n			</header>'),
(8, 'Ключевые слова', 'Ключевые слова', '', '', '', '', 'keywords', 'Ключевые слова', '<header>\n<h1 class="article-h1">Ключевые слова</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>', '<header>\n<h1 class="article-h1">Keywords</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>'),
(9, 'Учреждения', 'Учреждения', '', '', '', '', 'institutions', 'Учреждения', '<header>\n<h1 class="article-h1">Учреждения</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section class="useful-links">\n<ol class="ord-list">\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n</ol>\n</section>', '<header>\n<h1 class="article-h1">Institutions</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section class="useful-links">\n<ol class="ord-list">\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n</ol>\n</section>');

-- --------------------------------------------------------

--
-- Структура таблицы `page_resources`
--

DROP TABLE IF EXISTS `page_resources`;
CREATE TABLE IF NOT EXISTS `page_resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_url` varchar(100) NOT NULL,
  `number` int(10) unsigned NOT NULL,
  `caption` varchar(100) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `thumbnail` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `publications`
--

DROP TABLE IF EXISTS `publications`;
CREATE TABLE IF NOT EXISTS `publications` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` varchar(100) NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(255) NOT NULL,
  `ru_title` text NOT NULL,
  `en_title` text NOT NULL,
  `ru_annotation` text NOT NULL,
  `en_annotation` text NOT NULL,
  `ru_support` text NOT NULL,
  `en_support` text NOT NULL,
  `ru_bibliography` text NOT NULL,
  `en_bibliography` text NOT NULL,
  `ru_document` varchar(150) NOT NULL,
  `en_document` varchar(150) NOT NULL,
  `page` varchar(10) NOT NULL,
  `authors` varchar(255) NOT NULL,
  `issue` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Дамп данных таблицы `publications`
--

INSERT INTO `publications` (`id`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`, `page_url`, `ru_title`, `en_title`, `ru_annotation`, `en_annotation`, `ru_support`, `en_support`, `ru_bibliography`, `en_bibliography`, `ru_document`, `en_document`, `page`, `authors`, `issue`) VALUES
(1, 'Кластерообразование в структуре электронно-ионных проводников на основе допированного галлата лантана', 'Кластерообразование в структуре электронно-ионных проводников на основе допированного галлата лантана', '', 'Clustering in the structure of the electron-ion conductors based on doped lanthanum gallate', 'Clustering in the structure of the electron-ion conductors based on doped lanthanum gallate', '', 'klasteroobrazovanie-v-strukture-lektronno-ionnyh-provodnikov-na-osnove-dopirovannogo-gallata-lantana', 'Кластерообразование в структуре электронно-ионных проводников на основе допированного галлата лантана', 'Clustering in the structure of the electron-ion conductors based on doped lanthanum gallate', '<p>\r\n                             Исследованы магнитные свойства и спектры импеданса галлата лантана,  допированного двухвалентными элементами (Ca, Sr, Ba, Mg) и d-элементами с  разными соотношениями переходный металл:          двухвалентный элемент. Показано, что стабилизация структуры  перовскита достигается за счет образования прочных кластеров, включающих  в себя атомы переходного металла, двухвалентного          элемента и вакансии в кислородной подрешетке.  Кластерообразование усиливается с увеличением доли двухвалентного  элемента, при введении магния и при замене стронция на кальций или  барий,          что приводит к уменьшению проводимости за счет блокирования  кислородных вакансий кулоновским полем кластеров.\r\n</p>', '<p>\r\n                            Clustering in the structure of the electron-ion conductors based on doped lanthanum gallate<br>\r\n                            The magnetic properties and the impedance spectra lanthanum gallate  doped with divalent elements (Ca, Sr, Ba, Mg) and d-elements with  different ratios of transition metal to a divalent element. It is shown  that the stabilization of the perovskite structure is achieved by  forming strong clusters containing a transition metal atoms, a divalent  element and vacancies in the oxygen sublattice. Clustering increases  with increasing proportion of divalent element, introducing magnesium  and strontium replaced by calcium or barium, which leads to decrease in  the conductivity due to blocking of oxygen vacancies Coulomb field  clusters.\r\n</p>', '<ol class="ord-list">\r\n <li class="ord-item"><span class="gray">РФФИ грант № 08-05_00636</span></li>\r\n <li class="ord-item"><span class="gray">Новосибирский областной фонд поддержки науки и инновационной деятельности грант № 00-00-00000</span></li>\r\n <li class="ord-item"><span class="gray">Фонд имени И.Н.Герасимова грант № 50-04-12345</span></li>\r\n</ol>', '<p>\r\n  <span class="gray">РФФИ грант № 08-05_00636</span>\r\n</p>\r\n<ol class="ord-list">\r\n <li class="ord-item"><span class="gray">Новосибирский областной фонд поддержки науки и инновационной деятельности грант № 00-00-00000</span></li>\r\n <li class="ord-item"><span class="gray">Фонд имени И.Н.Герасимова грант № 50-04-12345</span></li>\r\n</ol>', '<ol class="ord-list">\r\n <li class="ord-item">         Чежина Н. В., Королев Д. А. // ЖОХ. – 2012. – V. 84. – P. 353         </li>\r\n <li class="ord-item">         Келлерман Д. Г., Шалаева Е. В., Гусев А. И. // ФТТ. – 2004. – V. 46. – P. 1633         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2010. – Т. 52. – Вып. 3. – С. 577–584         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2010. – Т. 52. – Вып. 6. – С. 1202–1205          </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2011. – Т. 53. – Вып. 3. – С. 569–572         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2011. – Т. 53. – Вып. 6. – С. 1224–1229         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2012. – Т. 54. – Вып. 2. – С. 378–381         </li>\r\n</ol>', '<ol class="ord-list">\r\n <li class="ord-item">         Чежина Н. В., Королев Д. А. // ЖОХ. – 2012. – V. 84. – P. 353         </li>\r\n <li class="ord-item">         Келлерман Д. Г., Шалаева Е. В., Гусев А. И. // ФТТ. – 2004. – V. 46. – P. 1633         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2010. – Т. 52. – Вып. 3. – С. 577–584         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2010. – Т. 52. – Вып. 6. – С. 1202–1205          </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2011. – Т. 53. – Вып. 3. – С. 569–572         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2011. – Т. 53. – Вып. 6. – С. 1224–1229         </li>\r\n <li class="ord-item">         Кузьмин М. В., Митцев М. А. // ФТТ. – 2012. – Т. 54. – Вып. 2. – С. 378–381         </li>\r\n</ol>', '2013/1/konferum-kategorii.pdf', '2013/1/105.pdf', '2', '2,1', 1),
(2, 'Lorem Ipsum - это текст-', 'Lorem Ipsum - это текст-"рыба"', 'Lorem Ipsum - это текст-', '', '', '', 'lorem-ipsum-to-tekst-', 'Lorem Ipsum - это текст-', 'de Finibus Bonorum et Malorum', '<p>\r\n <strong>Lorem Ipsum</strong>- это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n</p>', '<p>\r\n           "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do  eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad  minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip  ex ea commodo consequat. Duis aute irure dolor in reprehenderit in  voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur  sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt  mollit anim id est laborum."\r\n</p>', '<p>\r\n <strong>Lorem Ipsum</strong>- это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n</p>', '<p>\r\n           "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."\r\n</p>', '<p>\r\n <strong>Lorem Ipsum</strong>- это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.\r\n</p>', '<p>\r\n           "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."\r\n</p>', '2013/1/105.pdf', '2013/1/016.pdf', '6', '1', 1),
(28, '', '', '', '', '', '', 'lorem-ipsum-to-tekst-ryba', 'Lorem Ipsum - это текст-"рыба"', 'de Finibus Bonorum et Malorum', '<p>\r\n "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"\r\n</p>', '<p>\r\n "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"\r\n</p>', '<p>\r\n "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"\r\n</p>', '<p>\r\n "Sed ut perspiciatis unde omnis iste natus error sit voluptatem  accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab  illo inventore veritatis et quasi architecto beatae vitae dicta sunt  explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut  odit aut fugit, sed quia consequuntur magni dolores eos qui ratione  voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum  quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam  eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat  voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam  corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur?  Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse  quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo  voluptas nulla pariatur?"\r\n</p>', '<p>\r\n "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"\r\n</p>', '<p>\r\n "Sed ut perspiciatis unde omnis iste natus error sit voluptatem  accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab  illo inventore veritatis et quasi architecto beatae vitae dicta sunt  explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut  odit aut fugit, sed quia consequuntur magni dolores eos qui ratione  voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum  quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam  eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat  voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam  corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur?  Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse  quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo  voluptas nulla pariatur?"\r\n</p>', '2013/2/016.pdf', '2013/2/konferum-kategorii.pdf', '3', '', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `publications_comments`
--

DROP TABLE IF EXISTS `publications_comments`;
CREATE TABLE IF NOT EXISTS `publications_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `publication` int(10) unsigned NOT NULL,
  `issue` int(10) unsigned NOT NULL,
  `account` int(10) unsigned NOT NULL,
  `comment` text NOT NULL,
  `parent` int(10) unsigned NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `publications_comments`
--

INSERT INTO `publications_comments` (`id`, `publication`, `issue`, `account`, `comment`, `parent`, `date`) VALUES
(1, 1, 1, 4, 'Привет с контакта', 0, '2013-09-09 11:08:20'),
(2, 1, 1, 5, 'Привет из Фейсбука', 0, '2013-09-09 11:09:09');

-- --------------------------------------------------------

--
-- Структура таблицы `publications_resources`
--

DROP TABLE IF EXISTS `publications_resources`;
CREATE TABLE IF NOT EXISTS `publications_resources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `publication` int(11) NOT NULL,
  `issue` int(11) NOT NULL,
  `resource` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `publications_resources`
--

INSERT INTO `publications_resources` (`id`, `publication`, `issue`, `resource`) VALUES
(9, 1, 1, '{"file_name":"conferumcategories.doc","file_type":"application\\/msword","file_path":"S:\\/home\\/ptosnm\\/www\\/download\\/2013\\/1\\/","full_path":"S:\\/home\\/ptosnm\\/www\\/download\\/2013\\/1\\/conferumcategories.doc","raw_name":"conferumcategories","orig_name":"conferumcategories.doc","client_name":"conferum__categories.doc","file_ext":".doc","file_size":63,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":""}');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('9dad6475d2507b06abca30309676defa', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; rv:23.0) Gecko/20100101 Firefox/23.0', 1378724775, 'a:5:{s:9:"user_data";s:0:"";s:12:"current_page";s:48:"http://ptosnm.ru/ru/issue/2013/1/1/publication/1";s:5:"logon";s:32:"d41d8cd98f00b204e9800998ecf8427e";s:7:"account";s:22:"{"id":"5","group":"1"}";s:7:"profile";s:699:"{"id":"5","group":"1","vkid":"0","vk_access_token":"","facebook_access_token":"CAADQjsffLFsBAM71YG8Pv6M5rrFjR7hzyLISeblBLZBzZB9ZAcbcrTAgFJmDoX7CMrKNuZAl1A6XWZC3eWmECnimIvEiJQZCU21eocWa33fJjDCXeZCi7IZATQv6OKqi64tHKwvVkQKADyzZAobZAoWfA1iDDBgZAr90WSxiJFDWxIdI1aplUZCZBm4rM","facebookid":"100001912017351","photo":null,"name":"{{slash}}u0412{{slash}}u043b{{slash}}u0430{{slash}}u0434{{slash}}u0438{{slash}}u043c{{slash}}u0438{{slash}}u0440 {{slash}}u0425{{slash}}u0430{{slash}}u0440{{slash}}u0441{{slash}}u0435{{slash}}u0435{{slash}}u0432","link":"https:{{slash}}/{{slash}}/www.facebook.com{{slash}}/profile.php?id=100001912017351","login":"","password":"","signdate":"2013-09-09 15:08:56","active":"1"}";}');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
