-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Сен 09 2013 г., 17:51
-- Версия сервера: 5.1.40-community
-- Версия PHP: 5.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `ptosnm`
--
CREATE DATABASE IF NOT EXISTS `ptosnm` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `ptosnm`;

-- --------------------------------------------------------

--
-- Структура таблицы `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `vkid` int(11) NOT NULL,
  `vk_access_token` text NOT NULL,
  `facebook_access_token` text NOT NULL,
  `facebookid` bigint(20) NOT NULL,
  `photo` mediumblob NOT NULL,
  `name` varchar(100) NOT NULL,
  `link` varchar(200) NOT NULL,
  `login` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `signdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `email` (`login`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `accounts`
--

INSERT INTO `accounts` (`id`, `group`, `vkid`, `vk_access_token`, `facebook_access_token`, `facebookid`, `photo`, `name`, `link`, `login`, `password`, `signdate`, `active`) VALUES
(1, 0, 0, '', '', 0, '', '', '', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '2013-09-03 08:28:59', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE IF NOT EXISTS `authors` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `institution` int(10) unsigned NOT NULL,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` varchar(100) NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(100) NOT NULL,
  `ru_name` varchar(100) NOT NULL,
  `en_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ru_position` varchar(255) NOT NULL,
  `en_position` varchar(255) NOT NULL,
  `ru_address` text NOT NULL,
  `en_address` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `institutions`
--

DROP TABLE IF EXISTS `institutions`;
CREATE TABLE IF NOT EXISTS `institutions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_small_title` varchar(100) NOT NULL,
  `en_small_title` varchar(100) NOT NULL,
  `ru_title` text NOT NULL,
  `ru_description` text NOT NULL,
  `en_title` text NOT NULL,
  `en_description` text NOT NULL,
  `ru_contacts` text NOT NULL,
  `en_contacts` text NOT NULL,
  `ru_site_link` varchar(100) NOT NULL,
  `en_site_link` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `issues`
--

DROP TABLE IF EXISTS `issues`;
CREATE TABLE IF NOT EXISTS `issues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` varchar(100) NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(255) NOT NULL,
  `ru_title` varchar(100) NOT NULL,
  `en_title` varchar(100) NOT NULL,
  `number` int(10) unsigned NOT NULL,
  `month` tinyint(2) unsigned NOT NULL,
  `year` int(10) unsigned NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `keywords`
--

DROP TABLE IF EXISTS `keywords`;
CREATE TABLE IF NOT EXISTS `keywords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `word_hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `matching`
--

DROP TABLE IF EXISTS `matching`;
CREATE TABLE IF NOT EXISTS `matching` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `word` int(10) unsigned NOT NULL,
  `publication` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` text NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `ru_content` text NOT NULL,
  `en_content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`, `page_url`, `title`, `ru_content`, `en_content`) VALUES
(1, 'Фазовые переходы, упорядоченные состояния и новые материалы', 'Фазовые переходы, упорядоченные состояния и новые материалы', '', 'Phase transitions, ordered states and new materials', 'Phase transitions, ordered states and new materials', '', 'home', 'Главная страница', '<header>\n<h1 class="article-h1">Фазовые переходы, упорядоченные состояния и новые материалы</h1>\n<p class="desc">\n	        Журнал «Фазовые переходы, упорядоченные состояния и новые материалы» - первый в России электронный журнал,  посвященный широкому кругу вопросов из области физики конденсированных сред.  В нем публикуются результаты оригинальных исследований и обзоры, посвященные актуальным прикладным и  фундаментальным вопросам по темам:\n</p>\n</header>\n<p class="themes">\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки</li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики</li>\n	<li class="themes-item">Сверхпроводимость</li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур</li>\n	<li class="themes-item">Теория фазовых диаграмм</li>\n	<li class="themes-item">Свойства металлов и сплавов</li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации</li>\n	<li class="themes-item">Напряженные состояния и пластичность</li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности</li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности</li>\n	<li class="themes-item">Полимеры, жидкие кристаллы</li>\n	<li class="themes-item">Электронные свойства твердых тел</li>\n	<li class="themes-item">Атомные кластеры, фуллерены</li>\n</ul>\n<p class="freq-div">\n</p>\n<p>\n	        Периодичность журнала в свет - ежемесячно. Учредителем является Институт физики Южного федерального университета.\n</p>', '<header>\n<h1 class="article-h1">Phase transitions, ordered states and new materials</h1>\n<p class="desc">\n	          Журнал «Фазовые переходы, упорядоченные состояния и новые материалы» - первый в России электронный журнал,  посвященный широкому кругу вопросов из области физики конденсированных сред.  В нем публикуются результаты оригинальных исследований и обзоры, посвященные актуальным прикладным и  фундаментальным вопросам по темам:\n</p>\n</header>\n<p class="themes">\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки</li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики</li>\n	<li class="themes-item">Сверхпроводимость</li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур</li>\n	<li class="themes-item">Теория фазовых диаграмм</li>\n	<li class="themes-item">Свойства металлов и сплавов</li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации</li>\n	<li class="themes-item">Напряженные состояния и пластичность</li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности</li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности</li>\n	<li class="themes-item">Полимеры, жидкие кристаллы</li>\n	<li class="themes-item">Электронные свойства твердых тел</li>\n	<li class="themes-item">Атомные кластеры, фуллерены</li>\n</ul>\n<p class="freq-div">\n</p>\n<p>\n	          Периодичность журнала в свет - ежемесячно. Учредителем является Институт физики Южного федерального университета.\n</p>'),
(2, 'Выпуски', 'Выпуски', '', '', '', '', 'issues', 'Выпуски', '<header>\n<h1 class="article-h1">Выпуски</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>', '<header>\n<h1 class="article-h1">Issues</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>'),
(3, 'Информация для авторов', 'Информация для авторов', '', '', '', '', 'for-authors', 'Информация для авторов', '<header>\n<h1 class="article-h1">Информация для авторов</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section>\n<p class="themes">\n</p>\n<p class="theme-header">\n	 В нашем журнале публикуются оригинальные работы и обзоры по широкому спектру вопросов физики твердого тела. Основные рубрики:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки         </li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики         </li>\n	<li class="themes-item">Сверхпроводимость         </li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур         </li>\n	<li class="themes-item">Теория фазовых диаграмм         </li>\n	<li class="themes-item">Свойства металлов и сплавов         </li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации         </li>\n	<li class="themes-item">Напряженные состояния и пластичность         </li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности         </li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности         </li>\n	<li class="themes-item">Полимеры, жидкие кристаллы         </li>\n	<li class="themes-item">Электронные свойства твердых тел         </li>\n	<li class="themes-item">Атомные кластеры, фуллерены         </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	 Каждая статья должна сопровождаться следующей информацией:\n</p>\n<ol class="ord-list">\n	<li class="ord-item">         название статьи на русском и английском языках         </li>\n	<li class="ord-item">         информация о каждом из соавторов (см. ниже)         </li>\n	<li class="ord-item">         краткая аннотация на русском и английском языках         </li>\n	<li class="ord-item">         название рубрики журнала, к которой следует отнести статью          </li>\n	<li class="ord-item">         список ключевых слов на русском и английском языках (см. ниже).         </li>\n</ol>\n</section><section>\n<p class="theme-header">\n	 Информация об авторе или соавторах статьи должна быть подана в следующем виде:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">если в нашем журнале уже были опубликованы статьи с участием данного автора, достаточно указать это и предоставить фамилию, имя и отчество автора          </li>\n	<li class="themes-item">если автор публикуется у нас впервые, следует указать:\n	<ol class="ord-list">\n		<li class="ord-item">         фамилию, имя, отчество на русском языке, а также фамилию и имя на английском языке (для иностранных авторов – только на английском)         </li>\n		<li class="ord-item">         название учреждения, в котором работает автор, на русском и английском языках, а также ссылку на сайт учреждения (если он есть)         </li>\n		<li class="ord-item">         электронный адрес (если он есть) и информацию о том, согласен ли автор, чтобы этот электронный адрес был опубликован на его страничке нашего сайта         </li>\n	</ol>\n	</li>\n</ul>\n</section><section class="notes">\n<p class="theme-header">\n	 Замечания:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Словосочетание "ключевые слова" следует понимать традиционным для научных журналов способом. Так, "теория симметрии" или "рентгеноструктурный анализ" могут быть выбраны в качестве ключевых слов, несмотря на то, что с точки зрения филологии словами они не являются. При выборе самих ключевых слов для пометки статьи также следует руководствоваться традициями журналов по физике твердого тела. Кроме того, следует учитывать, что в электронном формате журнала ключевые слова служат для быстрого поиска статей по схожей тематике – таким образом, имеет определенный смысл в качестве ключевых слов выбирать то, что уже служит в таком качестве в тех статьях нашего журнала, которые, как Вам кажется, близки по тематике к Вашей статье.          </li>\n	<li class="themes-item">Электронный журнал “Фазовые переходы, упорядоченные состояния и новые материалы” индексируется в нескольких библиографических базах (база данных ФГУП НТЦ Информрегистр, электронная научная библиотека eLIBRARY.ru). Считаем нужным предупредить о том, что некоторые из этих баз не обладают технической возможностью хранить тексты формул в их естественном виде. Например, в случае, если в названии или аннотации статьи, опубликованной в нашем или любом другом журнале, встретится формула “PbFexNb1-xO3”, в базе Информрегистра она, по независящим от нас причинам, будет выглядеть как “PbFexNb1-xO3”.                 </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	 К оформлению текстов статей предъявляются следующие требования:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">редакция принимает только статьи, представленные в электронном виде, в формате doc или tex.          </li>\n	<li class="themes-item">рисунки также следует предоставлять в электронном виде, в любом из распространенных растровых форматов (jpg, gif, pcx, bmp…). Работа по переводу фотографий и снимков других видов в электронный вид, ложится на авторов статьи.          </li>\n	<li class="themes-item">рисунки должны быть выполнены таким образом, чтобы по возможности не нуждаться в последующем редактировании. Все важные детали должны быть изображены так, чтобы быть различимыми при изменении размеров рисунка до ширины в одну стандартную журнальную колонку или до ширины страницы А4. Желательно, чтобы надписи на всех рисунках, относящихся к одной статье, были сделаны в едином стиле.          </li>\n	<li class="themes-item">в случае использования формата doc, желательно, чтобы формулы были набраны в редакторе формул MathType.         </li>\n</ul>\n</section>', '<header>\n<h1 class="article-h1">Information for Authors</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section>\n<p class="themes">\n</p>\n<p class="theme-header">\n	  В нашем журнале публикуются оригинальные работы и обзоры по широкому спектру вопросов физики твердого тела. Основные рубрики:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки         </li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики         </li>\n	<li class="themes-item">Сверхпроводимость         </li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур         </li>\n	<li class="themes-item">Теория фазовых диаграмм         </li>\n	<li class="themes-item">Свойства металлов и сплавов         </li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации         </li>\n	<li class="themes-item">Напряженные состояния и пластичность         </li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности         </li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности         </li>\n	<li class="themes-item">Полимеры, жидкие кристаллы         </li>\n	<li class="themes-item">Электронные свойства твердых тел         </li>\n	<li class="themes-item">Атомные кластеры, фуллерены         </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	  Каждая статья должна сопровождаться следующей информацией:\n</p>\n<ol class="ord-list">\n	<li class="ord-item">         название статьи на русском и английском языках         </li>\n	<li class="ord-item">         информация о каждом из соавторов (см. ниже)         </li>\n	<li class="ord-item">         краткая аннотация на русском и английском языках         </li>\n	<li class="ord-item">         название рубрики журнала, к которой следует отнести статью          </li>\n	<li class="ord-item">         список ключевых слов на русском и английском языках (см. ниже).         </li>\n</ol>\n</section><section>\n<p class="theme-header">\n	  Информация об авторе или соавторах статьи должна быть подана в следующем виде:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">если в нашем журнале уже были опубликованы статьи с участием данного автора, достаточно указать это и предоставить фамилию, имя и отчество автора          </li>\n	<li class="themes-item">если автор публикуется у нас впервые, следует указать:\n	<ol class="ord-list">\n		<li class="ord-item">         фамилию, имя, отчество на русском языке, а также фамилию и имя на английском языке (для иностранных авторов – только на английском)         </li>\n		<li class="ord-item">         название учреждения, в котором работает автор, на русском и английском языках, а также ссылку на сайт учреждения (если он есть)         </li>\n		<li class="ord-item">         электронный адрес (если он есть) и информацию о том, согласен ли автор, чтобы этот электронный адрес был опубликован на его страничке нашего сайта         </li>\n	</ol>\n	</li>\n</ul>\n</section><section class="notes">\n<p class="theme-header">\n	  Замечания:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Словосочетание "ключевые слова" следует понимать традиционным для научных журналов способом. Так, "теория симметрии" или "рентгеноструктурный анализ" могут быть выбраны в качестве ключевых слов, несмотря на то, что с точки зрения филологии словами они не являются. При выборе самих ключевых слов для пометки статьи также следует руководствоваться традициями журналов по физике твердого тела. Кроме того, следует учитывать, что в электронном формате журнала ключевые слова служат для быстрого поиска статей по схожей тематике – таким образом, имеет определенный смысл в качестве ключевых слов выбирать то, что уже служит в таком качестве в тех статьях нашего журнала, которые, как Вам кажется, близки по тематике к Вашей статье.          </li>\n	<li class="themes-item">Электронный журнал “Фазовые переходы, упорядоченные состояния и новые материалы” индексируется в нескольких библиографических базах (база данных ФГУП НТЦ Информрегистр, электронная научная библиотека eLIBRARY.ru). Считаем нужным предупредить о том, что некоторые из этих баз не обладают технической возможностью хранить тексты формул в их естественном виде. Например, в случае, если в названии или аннотации статьи, опубликованной в нашем или любом другом журнале, встретится формула “PbFexNb1-xO3”, в базе Информрегистра она, по независящим от нас причинам, будет выглядеть как “PbFexNb1-xO3”.                 </li>\n</ul>\n</section><section>\n<p class="theme-header">\n	  К оформлению текстов статей предъявляются следующие требования:\n</p>\n<ul class="themes-list">\n	<li class="themes-item">редакция принимает только статьи, представленные в электронном виде, в формате doc или tex.          </li>\n	<li class="themes-item">рисунки также следует предоставлять в электронном виде, в любом из распространенных растровых форматов (jpg, gif, pcx, bmp…). Работа по переводу фотографий и снимков других видов в электронный вид, ложится на авторов статьи.          </li>\n	<li class="themes-item">рисунки должны быть выполнены таким образом, чтобы по возможности не нуждаться в последующем редактировании. Все важные детали должны быть изображены так, чтобы быть различимыми при изменении размеров рисунка до ширины в одну стандартную журнальную колонку или до ширины страницы А4. Желательно, чтобы надписи на всех рисунках, относящихся к одной статье, были сделаны в едином стиле.          </li>\n	<li class="themes-item">в случае использования формата doc, желательно, чтобы формулы были набраны в редакторе формул MathType.         </li>\n</ul>\n</section>'),
(4, 'Редколлегия', 'Редколлегия', '', '', '', '', 'editorial', 'Редколлегия', '<header>\n<h1 class="article-h1">Редколлегия</h1>\n</header><section class="editorial">\n<ul class="ed-position">\n	<li>\n	<p class="position-header">\n		Главный редактор\n	</p>\n	<dl class="name-prof">\n		<dt>Сахненко Владимир Павлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		Заместители главного редактора\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Панченко Евгений Михайлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		Ученый секретарь\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		Члены редакционного совета\n	</p>\n	<dl class="name-prof">\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		<dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n</ul>\n</section>', '<header>\n<h1 class="article-h1">Editorial</h1>\n</header><section class="editorial">\n<ul class="ed-position">\n	<li>\n	<p class="position-header">\n		 Главный редактор\n	</p>\n	<dl class="name-prof">\n		<dt>Сахненко Владимир Павлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		 Заместители главного редактора\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Панченко Евгений Михайлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		 Ученый секретарь\n	</p>\n	<dl class="name-prof">\n		<dt>Гуфан Юрий Михайлович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n	<li>\n	<p class="position-header">\n		 Члены редакционного совета\n	</p>\n	<dl class="name-prof">\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Ахкубеков Анатолий Амишевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Балакирев Владимир Федорович</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n		<dt>Барлаков Хиса шамильевич</dt>\n		 <dd>доктор, профессор физико-математических наук</dd>\n	</dl>\n	</li>\n</ul>\n</section>'),
(5, 'Полезные ссылки', 'Полезные ссылки', '', '', '', '', 'usefull-links', 'Полезные ссылки', '<header>\n<h1 class="article-h1">Полезные ссылки</h1>\n</header><section class="useful-links">\n<dl>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n</dl>\n</section>', ''),
(6, 'Поиск', 'Поиск', '', 'Search', 'Search', '', 'search', 'Поиск', '<header>\n<h1 class="article-h1">Поиск</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>', '<header>\n<h1 class="article-h1">Search</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>'),
(7, 'Авторы', 'Авторы', '', '', '', '', 'authors', 'Авторы', '<header>\n				<h1 class="article-h1">Авторы</h1>\n				<div class="delicate-design-stroke"></div>\n			</header>', '<header>\n				<h1 class="article-h1">Authors</h1>\n				<div class="delicate-design-stroke"></div>\n			</header>'),
(8, 'Ключевые слова', 'Ключевые слова', '', '', '', '', 'keywords', 'Ключевые слова', '<header>\n<h1 class="article-h1">Ключевые слова</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>', '<header>\n<h1 class="article-h1">Keywords</h1>\n<p class="delicate-design-stroke">\n</p>\n</header>'),
(9, 'Учреждения', 'Учреждения', '', '', '', '', 'institutions', 'Учреждения', '<header>\n<h1 class="article-h1">Учреждения</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section class="useful-links">\n<ol class="ord-list">\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n</ol>\n</section>', '<header>\n<h1 class="article-h1">Institutions</h1>\n<p class="delicate-design-stroke">\n</p>\n</header><section class="useful-links">\n<ol class="ord-list">\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n	<li class="ord-item"> Федеральное государственное казенное образовательное учреждение высшего профессионального образования «Московский университет Министерства внутренних дел Российской Федерации» 117437, г. Москва, ул. Академика Волгина, д. 12 </li>\n</ol>\n</section>'),
(10, 'Футтер', '', '', 'Footer', '', '', 'footer', 'Футтер', '<p class="footer-content">\n</p>\n<div class="delicate-design-stroke">\n	<p class="issn">\n		ISSN 2073-0373\n	</p>\n	<p class="massm-sert">\n		<a class="no-clickble" href="">Свидетельство регистрации СМИ</a>\n	</p>\n	<p class="age">\n	</p>\n	<p>\n		0+\n	</p>\n</div>', '<div class="footer-content">\n	        		<div class="delicate-design-stroke">\n	        		</div>	\n	        		<div class="issn">\n	        			ISSN 2073-0373\n	        		</div>\n	        		<div class="massm-sert">\n	        			<a href="#">Evidence of registration of mass media</a>\n	        		</div>\n	        		<div class="age">\n	        			<p>0+</p>\n	        		</div>       \n        		</div> 	');

-- --------------------------------------------------------

--
-- Структура таблицы `page_resources`
--

DROP TABLE IF EXISTS `page_resources`;
CREATE TABLE IF NOT EXISTS `page_resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_url` varchar(100) NOT NULL,
  `number` int(10) unsigned NOT NULL,
  `caption` varchar(100) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `thumbnail` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `publications`
--

DROP TABLE IF EXISTS `publications`;
CREATE TABLE IF NOT EXISTS `publications` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` varchar(100) NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` varchar(100) NOT NULL,
  `page_url` varchar(255) NOT NULL,
  `ru_title` text NOT NULL,
  `en_title` text NOT NULL,
  `ru_annotation` text NOT NULL,
  `en_annotation` text NOT NULL,
  `ru_support` text NOT NULL,
  `en_support` text NOT NULL,
  `ru_bibliography` text NOT NULL,
  `en_bibliography` text NOT NULL,
  `ru_document` varchar(150) NOT NULL,
  `en_document` varchar(150) NOT NULL,
  `page` varchar(10) NOT NULL,
  `authors` varchar(255) NOT NULL,
  `issue` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `publications_comments`
--

DROP TABLE IF EXISTS `publications_comments`;
CREATE TABLE IF NOT EXISTS `publications_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `publication` int(10) unsigned NOT NULL,
  `issue` int(10) unsigned NOT NULL,
  `account` int(10) unsigned NOT NULL,
  `comment` text NOT NULL,
  `parent` int(10) unsigned NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `publications_resources`
--

DROP TABLE IF EXISTS `publications_resources`;
CREATE TABLE IF NOT EXISTS `publications_resources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `publication` int(11) NOT NULL,
  `issue` int(11) NOT NULL,
  `resource` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('9dad6475d2507b06abca30309676defa', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; rv:23.0) Gecko/20100101 Firefox/23.0', 1378734266, 'a:5:{s:9:"user_data";s:0:"";s:12:"current_page";s:49:"http://ptosnm.ru/ru/issue/2013/2/2/publication/28";s:5:"logon";s:32:"21232f297a57a5a743894a0e4a801fc3";s:7:"account";s:22:"{"id":"2","group":"0"}";s:7:"profile";s:699:"{"id":"5","group":"1","vkid":"0","vk_access_token":"","facebook_access_token":"CAADQjsffLFsBAM71YG8Pv6M5rrFjR7hzyLISeblBLZBzZB9ZAcbcrTAgFJmDoX7CMrKNuZAl1A6XWZC3eWmECnimIvEiJQZCU21eocWa33fJjDCXeZCi7IZATQv6OKqi64tHKwvVkQKADyzZAobZAoWfA1iDDBgZAr90WSxiJFDWxIdI1aplUZCZBm4rM","facebookid":"100001912017351","photo":null,"name":"{{slash}}u0412{{slash}}u043b{{slash}}u0430{{slash}}u0434{{slash}}u0438{{slash}}u043c{{slash}}u0438{{slash}}u0440 {{slash}}u0425{{slash}}u0430{{slash}}u0440{{slash}}u0441{{slash}}u0435{{slash}}u0435{{slash}}u0432","link":"https:{{slash}}/{{slash}}/www.facebook.com{{slash}}/profile.php?id=100001912017351","login":"","password":"","signdate":"2013-09-09 15:08:56","active":"1"}";}');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
