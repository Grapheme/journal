-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Сен 03 2013 г., 21:37
-- Версия сервера: 5.1.40-community
-- Версия PHP: 5.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `ptosnm`
--
CREATE DATABASE IF NOT EXISTS `ptosnm` DEFAULT CHARACTER SET cp1251 COLLATE cp1251_general_ci;
USE `ptosnm`;

-- --------------------------------------------------------

--
-- Структура таблицы `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `signdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `email` (`login`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `accounts`
--

INSERT INTO `accounts` (`id`, `login`, `password`, `signdate`, `active`) VALUES
(2, 'admin', 'e10adc3949ba59abbe56e057f20f883e', '2013-09-03 08:28:59', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `keywords`
--

DROP TABLE IF EXISTS `keywords`;
CREATE TABLE IF NOT EXISTS `keywords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `word_hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` text NOT NULL,
  `page_description` text NOT NULL,
  `page_h1` text NOT NULL,
  `page_url` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `page_title`, `page_description`, `page_h1`, `page_url`, `title`, `content`) VALUES
(1, 'Главная страница', 'Главная страница', '', 'home', 'Главная страница', '<header>\n<h1 class="article-h1">Фазовые переходы, упорядоченные состояния и новые материалы</h1>\n<p class="desc">\n	    Журнал «Фазовые переходы, упорядоченные состояния и новые материалы» - первый в России электронный журнал,  посвященный широкому кругу вопросов из области физики конденсированных сред.  В нем публикуются результаты оригинальных исследований и обзоры, посвященные актуальным прикладным и  фундаментальным вопросам по темам:\n</p>\n</header>\n<p class="themes">\n</p>\n<ul class="themes-list">\n	<li class="themes-item">Динамика и устойчивость кристаллической решетки</li>\n	<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики</li>\n	<li class="themes-item">Сверхпроводимость</li>\n	<li class="themes-item">Кристаллохимия, теория кристаллических структур</li>\n	<li class="themes-item">Теория фазовых диаграмм</li>\n	<li class="themes-item">Свойства металлов и сплавов</li>\n	<li class="themes-item">Фазовые переходы плавления и кристаллизации</li>\n	<li class="themes-item">Напряженные состояния и пластичность</li>\n	<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности</li>\n	<li class="themes-item">Низкоразмерные системы, физика поверхности</li>\n	<li class="themes-item">Полимеры, жидкие кристаллы</li>\n	<li class="themes-item">Электронные свойства твердых тел</li>\n	<li class="themes-item">Атомные кластеры, фуллерены</li>\n</ul>\n<p class="freq-div">\n</p>\n<p>\n	    Периодичность журнала в свет - ежемесячно. Учредителем является Институт физики Южного федерального университета.\n</p>'),
(2, 'Выпуски', 'Выпуски', '', 'issues', 'Выпуски', ''),
(3, 'Информация для авторов', 'Информация для авторов', '', 'for-authors', 'Информация для авторов', '<header>\r\n        			<h1 class="article-h1">Информация для авторов</h1>        			\r\n        		</header>        		\r\n        		<section>\r\n	        		<div class="themes"> \r\n	        			<div class="theme-header">В нашем журнале публикуются оригинальные работы и обзоры по широкому спектру вопросов физики твердого тела. Основные рубрики: </div>\r\n		        		<ul class="themes-list">\r\n		        			<li class="themes-item">Динамика и устойчивость кристаллической решетки\r\n		        			<li class="themes-item">Магнетизм. Сегнетоэлектричество мультиферроики\r\n		        			<li class="themes-item">Сверхпроводимость\r\n		        			<li class="themes-item">Кристаллохимия, теория кристаллических структур\r\n		        			<li class="themes-item">Теория фазовых диаграмм\r\n		        			<li class="themes-item">Свойства металлов и сплавов\r\n		        			<li class="themes-item">Фазовые переходы плавления и кристаллизации\r\n		        			<li class="themes-item">Напряженные состояния и пластичность\r\n		        			<li class="themes-item">Дефекты, дислокации, диффузия. Физика прочности\r\n		        			<li class="themes-item">Низкоразмерные системы, физика поверхности\r\n		        			<li class="themes-item">Полимеры, жидкие кристаллы\r\n		        			<li class="themes-item">Электронные свойства твердых тел\r\n		        			<li class="themes-item">Атомные кластеры, фуллерены\r\n		        		</ul>\r\n	        		</div>\r\n        		</section>\r\n        		<section>\r\n        			<div class="theme-header">Каждая статья должна сопровождаться следующей информацией:</div>\r\n        			<ol class="ord-list"> \r\n        				<li class="ord-item">\r\n        					<span>название статьи на русском и английском языках</span>\r\n        				</li>\r\n        				<li class="ord-item">\r\n        					<span>информация о каждом из соавторов (см. ниже)</span>\r\n        				</li>\r\n        				<li class="ord-item">\r\n        					<span>краткая аннотация на русском и английском языках</span>\r\n        				</li>\r\n        				<li class="ord-item">\r\n        					<span>название рубрики журнала, к которой следует отнести статью</span> \r\n        				</li>\r\n        				<li class="ord-item">\r\n        					<span>список ключевых слов на русском и английском языках (см. ниже).</span>\r\n        				</li>\r\n        			</ol>\r\n        		</section>\r\n        		<section>\r\n        			<div class="theme-header">Информация об авторе или соавторах статьи должна быть подана в следующем виде:</div>\r\n        			<ul class="themes-list">\r\n		        		<li class="themes-item">если в нашем журнале уже были опубликованы статьи с участием данного автора, достаточно указать это и предоставить фамилию, имя и отчество автора\r\n		        		<li class="themes-item">если автор публикуется у нас впервые, следует указать:\r\n		        			<ol class="ord-list"> \r\n		        				<li class="ord-item">\r\n		        					<span>фамилию, имя, отчество на русском языке, а также фамилию и имя на английском языке (для иностранных авторов – только на английском)</span>\r\n		        				</li>\r\n		        				<li class="ord-item">\r\n		        					<span>название учреждения, в котором работает автор, на русском и английском языках, а также ссылку на сайт учреждения (если он есть)</span>\r\n		        				</li>\r\n		        				<li class="ord-item">\r\n		        					<span>электронный адрес (если он есть) и информацию о том, согласен ли автор, чтобы этот электронный адрес был опубликован на его страничке нашего сайта</span>\r\n		        				</li>\r\n		        			</ol>\r\n		        	</ul>\r\n        		</section>\r\n        		<section class="notes">\r\n        			<div class="theme-header">Замечания:</div>\r\n        			<ul class="themes-list">\r\n		        		<li class="themes-item">Словосочетание "ключевые слова" следует понимать традиционным для научных журналов способом. Так, "теория симметрии" или "рентгеноструктурный анализ" могут быть выбраны в качестве ключевых слов, несмотря на то, что с точки зрения филологии словами они не являются. При выборе самих ключевых слов для пометки статьи также следует руководствоваться традициями журналов по физике твердого тела. Кроме того, следует учитывать, что в электронном формате журнала ключевые слова служат для быстрого поиска статей по схожей тематике – таким образом, имеет определенный смысл в качестве ключевых слов выбирать то, что уже служит в таком качестве в тех статьях нашего журнала, которые, как Вам кажется, близки по тематике к Вашей статье.\r\n		        		<li class="themes-item">Электронный журнал “Фазовые переходы, упорядоченные состояния и новые материалы” индексируется в нескольких библиографических базах (база данных ФГУП НТЦ Информрегистр, электронная научная библиотека eLIBRARY.ru). Считаем нужным предупредить о том, что некоторые из этих баз не обладают технической возможностью хранить тексты формул в их естественном виде. Например, в случае, если в названии или аннотации статьи, опубликованной в нашем или любом другом журнале, встретится формула “PbFexNb1-xO3”, в базе Информрегистра она, по независящим от нас причинам, будет выглядеть как “PbFexNb1-xO3”.		        			\r\n		        	</ul>\r\n        		</section>\r\n        		<section>\r\n        			<div class="theme-header">К оформлению текстов статей предъявляются следующие требования:</div>\r\n        			<ul class="themes-list">\r\n		        		<li class="themes-item">редакция принимает только статьи, представленные в электронном виде, в формате doc или tex.\r\n		        		<li class="themes-item">рисунки также следует предоставлять в электронном виде, в любом из распространенных растровых форматов (jpg, gif, pcx, bmp…). Работа по переводу фотографий и снимков других видов в электронный вид, ложится на авторов статьи.\r\n		        		<li class="themes-item">рисунки должны быть выполнены таким образом, чтобы по возможности не нуждаться в последующем редактировании. Все важные детали должны быть изображены так, чтобы быть различимыми при изменении размеров рисунка до ширины в одну стандартную журнальную колонку или до ширины страницы А4. Желательно, чтобы надписи на всех рисунках, относящихся к одной статье, были сделаны в едином стиле.\r\n		        		<li class="themes-item">в случае использования формата doc, желательно, чтобы формулы были набраны в редакторе формул MathType.\r\n		        	</ul>\r\n        		</section>'),
(4, 'Редколлегия', 'Редколлегия', '', 'editorial', 'Редколлегия', '<header>\r\n        			<h1 class="article-h1">Редколлегия</h1>        			\r\n        		</header>\r\n        		<section class="editorial">\r\n        			<ul class="ed-position">\r\n        				<li>\r\n        					<div class="position-header">Главный редактор</div>\r\n        					<dl class="name-prof">\r\n        						<dt>Сахненко Владимир Павлович</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        					</dl>\r\n        				</li>\r\n        				<li>\r\n        					<div class="position-header">Заместители главного редактора</div>\r\n        					<dl class="name-prof">\r\n        						<dt>Гуфан Юрий Михайлович</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						<dt>Панченко Евгений Михайлович</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        					</dl>\r\n        				</li>\r\n        				<li>\r\n        					<div class="position-header">Ученый секретарь</div>\r\n        					<dl class="name-prof">\r\n        						<dt>Гуфан Юрий Михайлович</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        					</dl>\r\n        				</li>\r\n        				<li>\r\n        					<div class="position-header">Члены редакционного совета</div>\r\n        					<dl class="name-prof">\r\n        						<dt>Ахкубеков Анатолий Амишевич</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						<dt>Балакирев Владимир Федорович</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						<dt>Барлаков Хиса шамильевич</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						<dt>Ахкубеков Анатолий Амишевич</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						<dt>Балакирев Владимир Федорович</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						<dt>Барлаков Хиса шамильевич</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						  <dt>Ахкубеков Анатолий Амишевич</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						<dt>Балакирев Владимир Федорович</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						<dt>Барлаков Хиса шамильевич</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						  <dt>Ахкубеков Анатолий Амишевич</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						<dt>Балакирев Владимир Федорович</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						<dt>Барлаков Хиса шамильевич</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						  <dt>Ахкубеков Анатолий Амишевич</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						<dt>Балакирев Владимир Федорович</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>\r\n        						<dt>Барлаков Хиса шамильевич</dt>\r\n        						  <dd>доктор, профессор физико-математических наук</dd>       						\r\n        					</dl>\r\n        				</li>\r\n        			</ul>\r\n        		</section>'),
(5, 'Полезные ссылки', 'Полезные ссылки', '', 'usefull-links', 'Полезные ссылки', '<header>\n<h1 class="article-h1">Полезные ссылки</h1>\n</header><section class="useful-links">\n<dl>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n	<dt><a href="google.com">Google.com</a></dt>\n	<dd> - крупнейшая сеть поисковых систем, принадлежащая корпорации Google Inc.</dd>\n	<dt><a href="yandex.ru">Yandex.ru</a></dt>\n	<dd> - российская ИТ-компания, владеющая одноимённой системой поиска в Сети и интернет-порталом.</dd>\n</dl>\n</section>'),
(6, 'Выпуски', 'Выпуски', '', 'issues', 'Выпуски', ''),
(7, 'Авторы', 'Авторы', '', 'authors', 'Авторы', ''),
(8, 'Ключевые слова', 'Ключевые слова', '', 'keywords', 'Ключевые слова', '');

-- --------------------------------------------------------

--
-- Структура таблицы `page_resources`
--

DROP TABLE IF EXISTS `page_resources`;
CREATE TABLE IF NOT EXISTS `page_resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_url` varchar(100) NOT NULL,
  `number` int(10) unsigned NOT NULL,
  `caption` varchar(100) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `thumbnail` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('5e62d2e6759e46bd3f7318aaee97bfc4', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; rv:23.0) Gecko/20100101 Firefox/23.0', 1378216629, ''),
('80b641fc1d06c29874bf6a70ec64ca11', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; rv:23.0) Gecko/20100101 Firefox/23.0', 1378216629, ''),
('ad743519f83e80c62c72040cbcd407d3', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; rv:23.0) Gecko/20100101 Firefox/23.0', 1378229749, 'a:4:{s:9:"user_data";s:0:"";s:5:"logon";s:32:"21232f297a57a5a743894a0e4a801fc3";s:7:"account";s:10:"{"id":"2"}";s:7:"profile";s:118:"{"id":"2","login":"admin","password":"e10adc3949ba59abbe56e057f20f883e","signdate":"2013-09-03 12:28:59","active":"1"}";}');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
